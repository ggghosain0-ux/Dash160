#!/usr/bin/env bash
# ==============================================================================
# DICOT Dashboard - Production VPS Automated Installer
# ==============================================================================
# A comprehensive, production-grade script optimized for deploying the DICOT
# dashboard onto a VPS (Virtual Private Server) or cloud instance (Ubuntu/Debian).
# Handles system updates, firewalling, PM2 daemons, and Cloudflare Tunnels.
# ==============================================================================

set -euo pipefail

# ------------------------------------------------------------------------------
# Typography & Colors
# ------------------------------------------------------------------------------
export COLOR_RESET="\033[0m"
export COLOR_BOLD="\033[1m"
export COLOR_DIM="\033[2m"
export COLOR_RED="\033[38;5;196m"
export COLOR_GREEN="\033[38;5;82m"
export COLOR_YELLOW="\033[38;5;214m"
export COLOR_BLUE="\033[38;5;27m"
export COLOR_CYAN="\033[38;5;51m"
export COLOR_PURPLE="\033[38;5;129m"

export ICON_SUCCESS="${COLOR_GREEN}✓${COLOR_RESET}"
export ICON_FAILURE="${COLOR_RED}✗${COLOR_RESET}"
export ICON_WARNING="${COLOR_YELLOW}!${COLOR_RESET}"
export ICON_INFO="${COLOR_BLUE}i${COLOR_RESET}"
export ICON_STEP="${COLOR_PURPLE}➔${COLOR_RESET}"

# Ensure running as root
check_root() {
  if [ "$EUID" -ne 0 ]; then
    echo -e "  ${ICON_FAILURE} ${COLOR_RED}This installer must be run as root.${COLOR_RESET}"
    echo -e "  Please re-run using: ${COLOR_BOLD}sudo ./install-vps.sh${COLOR_RESET}"
    exit 1
  fi
}

log_info() {
  echo -e "  ${ICON_INFO} ${COLOR_BLUE}$*${COLOR_RESET}"
}

log_success() {
  echo -e "  ${ICON_SUCCESS} ${COLOR_GREEN}$*${COLOR_RESET}"
}

log_warning() {
  echo -e "  ${ICON_WARNING} ${COLOR_YELLOW}$*${COLOR_RESET}"
}

log_error() {
  echo -e "  ${ICON_FAILURE} ${COLOR_RED}$*${COLOR_RESET}" >&2
}

log_step() {
  echo -e "\n${COLOR_BOLD}${COLOR_PURPLE}${ICON_STEP} $*${COLOR_RESET}"
}

print_banner() {
  clear
  echo -e "${COLOR_BOLD}${COLOR_PURPLE}"
  echo "    ██████╗ ██╗ ██████╗ ██████╗ ████████╗"
  echo "    ██╔══██╗██║██╔════╝██╔═══██╗╚══██╔══╝"
  echo "    ██║  ██║██║██║     ██║   ██║   ██║   "
  echo "    ██║  ██║██║██║     ██║   ██║   ██║   "
  echo "    ██████╔╝██║╚██████╗╚██████╔╝   ██║   "
  echo "    ╚═════╝ ╚═╝ ╚═════╝ ╚═════╝    ╚═╝   "
  echo -e "  Next-Generation Dashboard Installer (VPS Deployment)${COLOR_RESET}"
  echo -e "  ${COLOR_DIM}------------------------------------------------------------${COLOR_RESET}\n"
}

# Error Handler
handle_vps_error() {
  local exit_code=$?
  local failed_line=$1
  log_error "VPS Setup failed at line $failed_line with exit code $exit_code."
  log_warning "Check system logs or run with bash -x for verbose tracing."
  exit "$exit_code"
}
trap 'handle_vps_error $LINENO' ERR

# User prompt confirm helper
prompt_confirm() {
  local prompt_text=$1
  local default_val=$2
  local choice
  
  if [[ "$default_val" == "Y" ]]; then
    read -rp "  $prompt_text [Y/n]: " choice
    choice=${choice:-Y}
  else
    read -rp "  $prompt_text [y/N]: " choice
    choice=${choice:-N}
  fi
  
  if [[ "$choice" =~ ^[Yy]$ ]]; then
    return 0
  else
    return 1
  fi
}

# ------------------------------------------------------------------------------
# System Update & Dependency Installation
# ------------------------------------------------------------------------------
update_vps_packages() {
  log_step "Updating VPS Core Systems"
  
  log_info "Updating system package definitions..."
  apt-get update -y
  
  log_info "Upgrading existing libraries..."
  DEBIAN_FRONTEND=noninteractive apt-get upgrade -y
  
  log_info "Installing development toolchains and utilities..."
  DEBIAN_FRONTEND=noninteractive apt-get install -y \
    curl git wget build-essential python3 python3-pip lsof ufw jq unzip sudo
}

# ------------------------------------------------------------------------------
# Docker and Docker Compose Provisioning
# ------------------------------------------------------------------------------
install_docker_if_needed() {
  log_step "Verifying Docker Infrastructure"
  
  local install_docker=0
  if ! command -v docker >/dev/null 2>&1; then
    install_docker=1
  fi
  
  if [ "$install_docker" -eq 1 ]; then
    if prompt_confirm "Docker Engine was not found. Do you want to install Docker & Compose?" "Y"; then
      log_info "Installing Docker using official conveniency script..."
      curl -fsSL https://get.docker.com | sh
      
      log_info "Installing Docker Compose plugin..."
      apt-get install -y docker-compose-plugin || true
      
      systemctl enable docker
      systemctl start docker
      log_success "Docker Engine has been provisioned and started."
    fi
  else
    log_success "Docker Engine is already installed (${COLOR_DIM}$(docker --version)${COLOR_RESET})."
  fi
}

# ------------------------------------------------------------------------------
# Node.js Installation
# ------------------------------------------------------------------------------
install_node_runtime() {
  log_step "Configuring Node.js Environment"
  
  if ! command -v node >/dev/null 2>&1; then
    log_info "Downloading and configuring NodeSource Node.js v18 LTS GPG Keys..."
    curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
    log_info "Installing Node.js packages..."
    apt-get install -y nodejs
  fi
  
  log_success "Node.js environment configured: ${COLOR_DIM}$(node --version)${COLOR_RESET}"
}

# ------------------------------------------------------------------------------
# Application Deployment & Config
# ------------------------------------------------------------------------------
deploy_dashboard() {
  log_step "Deploying Dashboard Repository & Configurations"
  
  # Copy local .env.example if no .env exists
  if [ ! -f .env ]; then
    log_info "Generating production environment file (.env)..."
    cp .env.example .env
  fi
  
  # Configure local port
  export CONFIGURED_PORT=6009
  read -rp "  Specify dashboard production port [Default: 6009]: " custom_port
  CONFIGURED_PORT=${custom_port:-6009}
  
  # Set settings.json website port safely using Node
  log_info "Modifying settings.json listen port to ${CONFIGURED_PORT}..."
  node -e "
    const fs = require('fs');
    try {
      const settings = JSON.parse(fs.readFileSync('settings.json', 'utf8'));
      if (!settings.website) settings.website = {};
      settings.website.port = parseInt('$CONFIGURED_PORT');
      fs.writeFileSync('settings.json', JSON.stringify(settings, null, 2), 'utf8');
      console.log('SUCCESS');
    } catch (err) {
      console.error(err);
      process.exit(1);
    }
  " >/dev/null
  
  # Install Node dependencies (full install to include Tailwind CSS compiler)
  log_info "Installing development & production dependencies for asset compilation..."
  npm install
  
  # Build assets
  log_info "Compiling premium frontend Tailwind CSS assets..."
  if npm run build; then
    log_success "Tailwind CSS compiled successfully."
  else
    log_warning "Tailwind compilation skipped or encountered an error. Bypassing..."
  fi

  # Prune development dependencies to keep production footprint minimal
  log_info "Pruning development dependencies..."
  npm prune --production || true
}

# ------------------------------------------------------------------------------
# PM2 Process Manager Configuration
# ------------------------------------------------------------------------------
setup_pm2_process_manager() {
  log_step "Configuring PM2 Process Daemonization"
  
  log_info "Installing pm2 globally..."
  npm install -g pm2
  
  log_info "Registering DICOT Dashboard in PM2 daemon pool..."
  pm2 delete "dicot-dashboard" 2>/dev/null || true
  pm2 start app.js --name "dicot-dashboard"
  
  log_info "Enabling PM2 server start on machine boot..."
  # Fetch boot script commands from pm2
  local startup_cmd
  startup_cmd=$(pm2 startup systemd | grep "sudo env" || pm2 startup | grep "env" || echo "")
  
  if [ -n "$startup_cmd" ]; then
    eval "$startup_cmd"
  fi
  
  pm2 save
  log_success "PM2 configured. App is running & boot-persistence enabled."
}

# ------------------------------------------------------------------------------
# Network Security & Firewall Rules
# ------------------------------------------------------------------------------
configure_ufw_firewall() {
  log_step "Network Security & Firewall Rules"
  
  if prompt_confirm "Do you want to configure and enable UFW firewall?" "Y"; then
    log_info "Allowing standard Secure Shell connections (Port 22)..."
    ufw allow 22/tcp comment 'SSH Access'
    
    log_info "Allowing dashboard production port (${CONFIGURED_PORT})..."
    ufw allow "${CONFIGURED_PORT}/tcp" comment 'DICOT Dashboard Port'
    
    log_info "Allowing web standard ports (80/TCP, 443/TCP)..."
    ufw allow 80/tcp comment 'HTTP Webserver'
    ufw allow 443/tcp comment 'HTTPS Secure Webserver'
    
    log_info "Enabling Firewall rules..."
    echo "y" | ufw enable
    
    ufw status verbose
    log_success "UFW Network Firewall successfully enabled."
  fi
}

# ------------------------------------------------------------------------------
# Cloudflare Tunnel Integration
# ------------------------------------------------------------------------------
setup_cloudflare_tunnel() {
  log_step "Cloudflare Tunnel Integration"
  
  if ! prompt_confirm "Would you like to install and configure a Cloudflare Tunnel for secure public access?" "N"; then
    log_info "Cloudflare Tunnel step bypassed."
    return
  fi
  
  # Install cloudflared if missing
  if ! command -v cloudflared >/dev/null 2>&1; then
    log_info "Downloading the latest Cloudflare Tunnel client daemon..."
    local arch
    arch=$(uname -m)
    if [[ "$arch" == "x86_64" ]]; then
      curl -L -o /usr/local/bin/cloudflared https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64
    elif [[ "$arch" == "aarch64" || "$arch" == "arm64" ]]; then
      curl -L -o /usr/local/bin/cloudflared https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm64
    else
      curl -L -o /usr/local/bin/cloudflared https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-386
    fi
    chmod +x /usr/local/bin/cloudflared
    log_success "cloudflared client successfully installed."
  else
    log_success "cloudflared already installed (${COLOR_DIM}$(cloudflared --version)${COLOR_RESET})."
  fi
  
  echo -e "\nChoose your Cloudflare Tunnel Configuration Method:"
  echo -e "  [1] Zero Trust Token (Recommended - Headless & automated)"
  echo -e "  [2] Classic Interactive flow (Tunnel Login, Create & Domain bind)"
  read -rp "Select method [1-2]: " tunnel_method
  
  if [ "$tunnel_method" -eq 1 ]; then
    read -rsp "  Enter your Cloudflare Zero Trust Tunnel Token: " cf_token
    echo ""
    if [ -z "$cf_token" ]; then
      log_error "Token cannot be empty."
      return
    fi
    
    log_info "Installing Cloudflare service daemon..."
    cloudflared service uninstall 2>/dev/null || true
    cloudflared service install "$cf_token"
    
    systemctl start cloudflared
    systemctl enable cloudflared
    log_success "Cloudflare Tunnel service is successfully running."
  else
    log_info "Please authenticate the server with your Cloudflare Account..."
    log_info "Open the URL below in a web browser to grant permissions:"
    cloudflared tunnel login || true
    
    read -rp "  Press [Enter] once authorization is complete: "
    
    read -rp "  Enter a unique name for this tunnel (e.g., dicot-prod): " tunnel_name
    if [ -z "$tunnel_name" ]; then
      log_error "Tunnel name cannot be empty."
      return
    fi
    
    log_info "Creating Tunnel: $tunnel_name..."
    local tunnel_create_out
    tunnel_create_out=$(cloudflared tunnel create "$tunnel_name")
    local tunnel_uuid
    tunnel_uuid=$(echo "$tunnel_create_out" | grep -oE "[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}" | head -n 1)
    
    log_success "Created Tunnel UUID: $tunnel_uuid"
    
    read -rp "  Enter the domain or subdomain to bind to this tunnel (e.g., panel.yourdomain.com): " cf_domain
    if [ -z "$cf_domain" ]; then
      log_error "Domain/subdomain cannot be empty."
      return
    fi
    
    log_info "Configuring routing for domain: $cf_domain..."
    cloudflared tunnel route dns "$tunnel_name" "$cf_domain"
    
    # Generate config.yml
    log_info "Writing local Tunnel configuration..."
    mkdir -p /etc/cloudflared
    cat << EOF > /etc/cloudflared/config.yml
tunnel: ${tunnel_uuid}
credentials-file: /root/.cloudflared/${tunnel_uuid}.json

ingress:
  - hostname: ${cf_domain}
    service: http://localhost:${CONFIGURED_PORT}
  - service: http_status:404
EOF
    
    log_info "Registering as a systemd background service..."
    cloudflared service uninstall 2>/dev/null || true
    cloudflared service install
    
    systemctl start cloudflared
    systemctl enable cloudflared
    log_success "Cloudflare Tunnel online! Secure URL: https://${cf_domain}"
  fi
}

# ------------------------------------------------------------------------------
# Final Verification
# ------------------------------------------------------------------------------
validate_services() {
  log_step "Validating Deployment Integrity"
  
  sleep 2
  log_info "Checking local dashboard process listener status..."
  if curl -s -I "http://localhost:${CONFIGURED_PORT}" >/dev/null; then
    log_success "Local dashboard is fully operational & serving requests on port $CONFIGURED_PORT."
  else
    log_warning "Local health check returned no response. Check 'pm2 logs' for errors."
  fi
}

# ------------------------------------------------------------------------------
# Main Flow
# ------------------------------------------------------------------------------
main() {
  check_root
  print_banner
  
  update_vps_packages
  install_docker_if_needed
  install_node_runtime
  deploy_dashboard
  setup_pm2_process_manager
  configure_ufw_firewall
  setup_cloudflare_tunnel
  validate_services
  
  # Success Output
  echo -e "\n${COLOR_BOLD}${COLOR_GREEN}============================================================${COLOR_RESET}"
  echo -e "${COLOR_BOLD}${COLOR_GREEN}          DICOT PRODUCTION VPS SETUP COMPLETE!              ${COLOR_RESET}"
  echo -e "${COLOR_BOLD}${COLOR_GREEN}============================================================${COLOR_RESET}"
  echo -e "  - ${COLOR_BOLD}Process Manager Status:${COLOR_RESET} pm2 status"
  echo -e "  - ${COLOR_BOLD}Process Log Streams:${COLOR_RESET}    pm2 logs dicot-dashboard"
  echo -e "  - ${COLOR_BOLD}Port Configured:${COLOR_RESET}        ${CONFIGURED_PORT}"
  echo -e "  - ${COLOR_BOLD}Database File Path:${COLOR_RESET}     ./database.sqlite"
  echo -e "  - ${COLOR_BOLD}Firewall Status:${COLOR_RESET}        ufw status"
  echo -e "${COLOR_BOLD}${COLOR_GREEN}============================================================${COLOR_RESET}\n"
}

main "$@"
