#!/usr/bin/env bash
# ==============================================================================
# DICOT Dashboard - Local Development Installer
# ==============================================================================
# A production-quality, fully automated, and highly robust installation script
# designed to set up and configure the DICOT control panel for local development.
# Safe to run multiple times (idempotent).
# ==============================================================================

# Ensure strict bash shell execution parameters
set -euo pipefail

# ------------------------------------------------------------------------------
# Formatting and Visual Constants
# ------------------------------------------------------------------------------
export COLOR_RESET="\033[0m"
export COLOR_BOLD="\033[1m"
export COLOR_DIM="\033[2m"
export COLOR_RED="\033[38;5;196m"
export COLOR_GREEN="\033[38;5;82m"
export COLOR_YELLOW="\033[38;5;214m"
export COLOR_BLUE="\033[38;5;27m"
export COLOR_CYAN="\033[38;5;51m"
export COLOR_PURPLE="\033[38;5;129m"

# Visual indicators
export ICON_SUCCESS="${COLOR_GREEN}✓${COLOR_RESET}"
export ICON_FAILURE="${COLOR_RED}✗${COLOR_RESET}"
export ICON_WARNING="${COLOR_YELLOW}!${COLOR_RESET}"
export ICON_INFO="${COLOR_BLUE}i${COLOR_RESET}"
export ICON_STEP="${COLOR_PURPLE}➔${COLOR_RESET}"

# Temp file for cleaning up on abnormal termination
TMP_DIR=$(mktemp -d -t dicot-install-XXXXXX)

# ------------------------------------------------------------------------------
# Utility Functions
# ------------------------------------------------------------------------------
log_info() {
  echo -e "  ${ICON_INFO} ${COLOR_BLUE}$*${COLOR_RESET}"
}

log_success() {
  echo -e "  ${ICON_SUCCESS} ${COLOR_GREEN}$*${COLOR_RESET}"
}

log_warning() {
  echo -e "  ${ICON_WARNING} ${COLOR_YELLOW}$*${COLOR_RESET}"
}

log_error() {
  echo -e "  ${ICON_FAILURE} ${COLOR_RED}$*${COLOR_RESET}" >&2
}

log_step() {
  echo -e "\n${COLOR_BOLD}${COLOR_PURPLE}${ICON_STEP} $*${COLOR_RESET}"
}

cleanup() {
  rm -rf "$TMP_DIR"
}
trap cleanup EXIT

# Print beautiful header
print_banner() {
  clear
  echo -e "${COLOR_BOLD}${COLOR_CYAN}"
  echo "    ██████╗ ██╗ ██████╗ ██████╗ ████████╗"
  echo "    ██╔══██╗██║██╔════╝██╔═══██╗╚══██╔══╝"
  echo "    ██║  ██║██║██║     ██║   ██║   ██║   "
  echo "    ██║  ██║██║██║     ██║   ██║   ██║   "
  echo "    ██████╔╝██║╚██████╗╚██████╔╝   ██║   "
  echo "    ╚═════╝ ╚═╝ ╚═════╝ ╚═════╝    ╚═╝   "
  echo -e "  Next-Generation Dashboard Installer (Local Development)${COLOR_RESET}"
  echo -e "  ${COLOR_DIM}------------------------------------------------------------${COLOR_RESET}\n"
}

# Graceful failure handler
handle_failure() {
  local exit_code=$?
  local failed_line=$1
  log_error "Installation failed at line $failed_line with exit code $exit_code."
  log_warning "Troubleshooting tips:"
  log_info "- Verify that you have sufficient disk space."
  log_info "- Check your network connection and package manager mirrors."
  log_info "- Ensure you have administrative or sudo privileges."
  log_info "- For support, view the project documentation or log a GitHub issue."
  exit "$exit_code"
}
trap 'handle_failure $LINENO' ERR

# Ensure user confirmation prompt helper
prompt_confirm() {
  local prompt_text=$1
  local default_val=$2 # Y or N
  local choice
  
  if [[ "$default_val" == "Y" ]]; then
    read -rp "  $prompt_text [Y/n]: " choice
    choice=${choice:-Y}
  else
    read -rp "  $prompt_text [y/N]: " choice
    choice=${choice:-N}
  fi
  
  if [[ "$choice" =~ ^[Yy]$ ]]; then
    return 0
  else
    return 1
  fi
}

# ------------------------------------------------------------------------------
# System and Architecture Detection
# ------------------------------------------------------------------------------
detect_os() {
  log_step "System & Architecture Detection"
  
  # Detect operating system
  export OS_TYPE="Unknown"
  export PKG_MANAGER=""
  
  if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    OS_TYPE="Linux"
    if [ -f /etc/os-release ]; then
      . /etc/os-release
      OS_TYPE="$NAME"
    fi
  elif [[ "$OSTYPE" == "darwin"* ]]; then
    OS_TYPE="macOS"
  elif [[ "$OSTYPE" == "cygwin" || "$OSTYPE" == "msys" || "$OSTYPE" == "win32" ]]; then
    OS_TYPE="Windows (Native/Emulated)"
  fi
  
  # Check for WSL (Windows Subsystem for Linux)
  if [[ -f /proc/version ]] && grep -qiq microsoft /proc/version; then
    OS_TYPE="$OS_TYPE (WSL)"
  fi
  
  log_info "Detected OS: ${COLOR_BOLD}${OS_TYPE}${COLOR_RESET}"
  log_info "Detected CPU Architecture: ${COLOR_BOLD}$(uname -m)${COLOR_RESET}"

  # Detect specific cloud IDEs
  if [ -n "${CODESPACES:-}" ]; then
    log_success "Environment: ${COLOR_BOLD}GitHub Codespaces${COLOR_RESET} (Cloud Workspace)"
  elif [ -n "${GITPOD_WORKSPACE_ID:-}" ]; then
    log_success "Environment: ${COLOR_BOLD}Gitpod${COLOR_RESET} (Cloud Workspace)"
  elif [ -n "${IDX_WORKSPACE_ID:-}" ]; then
    log_success "Environment: ${COLOR_BOLD}Google IDX${COLOR_RESET} (Cloud Workspace)"
  fi

  # Detect available package manager
  if command -v apt-get >/dev/null 2>&1; then
    PKG_MANAGER="apt"
  elif command -v brew >/dev/null 2>&1; then
    PKG_MANAGER="brew"
  elif command -v dnf >/dev/null 2>&1; then
    PKG_MANAGER="dnf"
  elif command -v yum >/dev/null 2>&1; then
    PKG_MANAGER="yum"
  elif command -v pacman >/dev/null 2>&1; then
    PKG_MANAGER="pacman"
  elif command -v apk >/dev/null 2>&1; then
    PKG_MANAGER="apk"
  fi
  
  if [ -n "$PKG_MANAGER" ]; then
    log_info "Detected Package Manager: ${COLOR_BOLD}${PKG_MANAGER}${COLOR_RESET}"
  else
    log_warning "No recognized package manager found in the current system path."
  fi
}

# ------------------------------------------------------------------------------
# Dependency Verification and Installation
# ------------------------------------------------------------------------------
verify_dependencies() {
  log_step "Dependency Verification"
  
  # Helper to check command existence and print status
  check_cmd() {
    local cmd=$1
    local name=$2
    if command -v "$cmd" >/dev/null 2>&1; then
      echo -e "  [${ICON_SUCCESS}] $name: Installed (${COLOR_DIM}$("$cmd" --version 2>/dev/null | head -n 1)${COLOR_RESET})"
      return 0
    else
      echo -e "  [${ICON_FAILURE}] $name: Not Found"
      return 1
    fi
  }

  local has_git=0
  local has_node=0
  local has_docker=0
  local has_python=0

  check_cmd "git" "Git" || has_git=1
  check_cmd "node" "Node.js" || has_node=1
  check_cmd "docker" "Docker Daemon" || has_docker=1
  check_cmd "docker-compose" "Docker Compose" || has_docker=1
  check_cmd "python3" "Python 3" || has_python=1

  # Package managers (npm, pnpm, yarn, bun)
  echo -e "\n  ${COLOR_DIM}Checking Node.js Package Managers:${COLOR_RESET}"
  check_cmd "npm" "  - npm" || true
  check_cmd "pnpm" "  - pnpm" || true
  check_cmd "yarn" "  - yarn" || true
  check_cmd "bun" "  - bun" || true

  # Install missing base tools if possible
  if [ "$has_git" -eq 1 ] || [ "$has_node" -eq 1 ]; then
    log_warning "Critical developer dependencies are missing."
    if prompt_confirm "Would you like this script to try installing missing development tools?" "Y"; then
      install_missing_tools
    else
      log_error "Git and Node.js are absolute requirements. Cannot proceed without installation."
      exit 1
    fi
  fi
}

install_missing_tools() {
  log_step "Installing Missing Developer Tools"
  
  # Check if sudo is available
  local use_sudo=""
  if command -v sudo >/dev/null 2>&1 && [ "$EUID" -ne 0 ]; then
    use_sudo="sudo"
  fi

  if [ "$PKG_MANAGER" = "apt" ]; then
    log_info "Updating package cache..."
    $use_sudo apt-get update -y
    
    log_info "Installing Git and development tools..."
    $use_sudo apt-get install -y git build-essential python3 curl lsof
    
    # Install Node.js if missing
    if ! command -v node >/dev/null 2>&1; then
      log_info "Installing Node.js v18 (LTS)..."
      curl -fsSL https://deb.nodesource.com/setup_18.x | $use_sudo -E bash -
      $use_sudo apt-get install -y nodejs
    fi
  elif [ "$PKG_MANAGER" = "brew" ]; then
    log_info "Using Homebrew to install dependencies..."
    command -v git >/dev/null 2>&1 || brew install git
    command -v node >/dev/null 2>&1 || brew install node@18
    command -v python3 >/dev/null 2>&1 || brew install python3
  elif [ "$PKG_MANAGER" = "apk" ]; then
    log_info "Installing dependencies via APK..."
    $use_sudo apk add --no-cache git nodejs npm python3 make g++ lsof
  else
    log_error "Automatic tool installation is not fully supported on this platform ($OS_TYPE)."
    log_info "Please manually install: Git, Node.js v18+, and Python3."
    exit 1
  fi
  
  log_success "System-level developer tools validated."
}

# ------------------------------------------------------------------------------
# Port Collision Handling
# ------------------------------------------------------------------------------
check_port() {
  local port=$1
  # First check using lsof if available
  if command -v lsof >/dev/null 2>&1; then
    lsof -i :"$port" -t >/dev/null 2>&1 && return 1 || return 0
  fi
  
  # Check using ss
  if command -v ss >/dev/null 2>&1; then
    ss -lptn "sport = :$port" 2>/dev/null | grep -q "$port" && return 1 || return 0
  fi
  
  # Bash fallback port check
  (echo > /dev/tcp/127.0.0.1/"$port") >/dev/null 2>&1 && return 1 || return 0
}

get_process_on_port() {
  local port=$1
  if command -v lsof >/dev/null 2>&1; then
    lsof -i :"$port" -sTCP:LISTEN
  elif command -v ss >/dev/null 2>&1; then
    ss -lptn "sport = :$port" 2>/dev/null
  else
    echo "Unknown Process (Process detection commands missing)"
  fi
}

handle_port_setup() {
  log_step "Configuring Port Allocation"
  
  local target_port=6009
  local port_free=0
  
  while [ "$port_free" -eq 0 ]; do
    log_info "Checking availability of port ${COLOR_BOLD}$target_port${COLOR_RESET}..."
    if check_port "$target_port"; then
      log_success "Port $target_port is fully available."
      port_free=1
    else
      log_warning "Port $target_port is currently occupied!"
      
      # Print conflicting process info
      echo -e "\n${COLOR_DIM}--- Occupying Process Info ---${COLOR_RESET}"
      get_process_on_port "$target_port" || echo "Could not list process."
      echo -e "${COLOR_DIM}------------------------------${COLOR_RESET}\n"
      
      echo -e "Options:"
      echo -e "  [1] Try to stop the conflicting process automatically (requires kill/sudo)"
      echo -e "  [2] Specify a different custom port"
      echo -e "  [3] Terminate installation"
      
      read -rp "Select option [1-3]: " port_choice
      
      case "$port_choice" in
        1)
          log_info "Attempting to release port $target_port..."
          local pid=""
          if command -v lsof >/dev/null 2>&1; then
            pid=$(lsof -t -i :"$target_port" 2>/dev/null || true)
          fi
          
          if [ -n "$pid" ]; then
            log_info "Sending SIGTERM to process $pid..."
            kill -15 "$pid" 2>/dev/null || true
            sleep 1
            if ! check_port "$target_port"; then
              log_info "Process did not terminate. Escalating to SIGKILL..."
              kill -9 "$pid" 2>/dev/null || true
              sleep 1
            fi
            
            if check_port "$target_port"; then
              log_success "Successfully freed port $target_port."
              port_free=1
            else
              log_error "Could not terminate the process. Please free it manually or choose option 2."
            fi
          else
            log_error "Could not resolve process PID. Please use alternative options."
          fi
          ;;
        2)
          read -rp "Enter new port: " target_port
          if [[ ! "$target_port" =~ ^[0-9]+$ ]] || [ "$target_port" -lt 1024 ] || [ "$target_port" -gt 65535 ]; then
            log_error "Invalid port number. Port must be a number between 1024 and 65535."
            target_port=6009
          fi
          ;;
        *)
          log_error "User aborted installation."
          exit 1
          ;;
      esac
    fi
  done
  
  export CONFIGURED_PORT=$target_port
}

# ------------------------------------------------------------------------------
# Environment Generation & Config Manipulation
# ------------------------------------------------------------------------------
configure_environment() {
  log_step "Configuring Application Settings"
  
  # Copy .env if not existing
  if [ ! -f .env ]; then
    log_info "Generating localized .env file from .env.example..."
    cp .env.example .env
    
    # Set APP_URL locally
    if [[ "$OS_TYPE" == *"WSL"* ]] || [[ "$OS_TYPE" == *"Linux"* ]]; then
      # Attempt to find local IP
      local local_ip="localhost"
      if command -v hostname >/dev/null 2>&1; then
        local_ip=$(hostname -I | awk '{print $1}' 2>/dev/null || echo "127.0.0.1")
      fi
      sed -i "s|MY_APP_URL|http://${local_ip}:${CONFIGURED_PORT}|g" .env
    else
      sed -i "" "s|MY_APP_URL|http://localhost:${CONFIGURED_PORT}|g" .env 2>/dev/null || \
      sed -i "s|MY_APP_URL|http://localhost:${CONFIGURED_PORT}|g" .env
    fi
    log_success ".env environment file configured."
  else
    log_info "An existing .env file was detected. Skipping generation to protect your configs."
  fi

  # Safely modify settings.json with the chosen port using Node.js execution
  # This guarantees syntax-safe JSON updates without corrupting settings.json
  log_info "Updating local listening port to ${COLOR_BOLD}${CONFIGURED_PORT}${COLOR_RESET} in settings.json..."
  node -e "
    const fs = require('fs');
    try {
      const file = 'settings.json';
      const settings = JSON.parse(fs.readFileSync(file, 'utf8'));
      if (!settings.website) settings.website = {};
      settings.website.port = parseInt('$CONFIGURED_PORT');
      fs.writeFileSync(file, JSON.stringify(settings, null, 2), 'utf8');
      console.log('SUCCESS');
    } catch (err) {
      console.error(err);
      process.exit(1);
    }
  " >/dev/null || {
    log_error "Failed to update settings.json using Node.js script. Falling back to sed pattern replacement..."
    # Sed fallback
    if [[ "$OSTYPE" == "darwin"* ]]; then
      sed -i "" 's/"port": [0-9]*/"port": '"$CONFIGURED_PORT"'/g' settings.json
    else
      sed -i 's/"port": [0-9]*/"port": '"$CONFIGURED_PORT"'/g' settings.json
    fi
  }
  
  log_success "settings.json updated to listen on port ${CONFIGURED_PORT}."
}

# ------------------------------------------------------------------------------
# Install & Build Node Project
# ------------------------------------------------------------------------------
install_and_build_project() {
  log_step "Installing Node.js Dependencies"
  
  # Choose package manager
  local pm="npm"
  if command -v bun >/dev/null 2>&1; then
    pm="bun"
  elif command -v pnpm >/dev/null 2>&1; then
    pm="pnpm"
  elif command -v yarn >/dev/null 2>&1; then
    pm="yarn"
  fi
  
  log_info "Installing dependencies using: ${COLOR_BOLD}${pm}${COLOR_RESET}..."
  
  # Execute installation
  if [ "$pm" = "npm" ]; then
    npm install
  elif [ "$pm" = "bun" ]; then
    bun install
  elif [ "$pm" = "pnpm" ]; then
    pnpm install
  elif [ "$pm" = "yarn" ]; then
    yarn install
  fi
  
  log_success "Dependencies successfully installed."
  
  # Build Tailwind production assets
  log_step "Compiling Assets (Tailwind CSS)"
  if npm run build; then
    log_success "CSS Assets successfully built for production."
  else
    log_warning "Asset compilation failed. Check if asset configuration is correct."
  fi
}

# ------------------------------------------------------------------------------
# Start Service
# ------------------------------------------------------------------------------
start_service_interactively() {
  log_step "Finalizing and Starting Application"
  
  echo -e "How would you like to launch the local development environment?"
  echo -e "  [1] Start locally via Node.js (foreground, npm run start)"
  echo -e "  [2] Start in the background using PM2 (highly recommended)"
  echo -e "  [3] Build and run using Docker Compose"
  echo -e "  [4] Do not start right now (just finish installation)"
  
  read -rp "Select option [1-4]: " launch_choice
  
  case "$launch_choice" in
    1)
      log_info "Starting DICOT Dashboard locally... (Press Ctrl+C to stop)"
      npm run start
      ;;
    2)
      log_info "Verifying PM2 installation..."
      if ! command -v pm2 >/dev/null 2>&1; then
        log_info "Installing PM2 process manager globally..."
        npm install -g pm2 || sudo npm install -g pm2
      fi
      
      pm2 start app.js --name "dicot-dashboard"
      pm2 save
      log_success "DICOT Dashboard is running in the background!"
      log_info "Manage process using: 'pm2 logs' or 'pm2 status'."
      ;;
    3)
      if ! command -v docker-compose >/dev/null 2>&1 && ! docker compose version >/dev/null 2>&1; then
        log_error "Docker / Docker Compose was not found on this machine. Cannot start containerized."
        return
      fi
      
      log_info "Generating local Docker configuration files..."
      # Create Dockerfile
      cat << 'EOF' > Dockerfile
# Production-ready Dockerfile for DICOT Dashboard
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build
EXPOSE 6009
CMD ["npm", "start"]
EOF

      # Create docker-compose.yml
      cat << EOF > docker-compose.yml
version: '3.8'
services:
  dicot-dashboard:
    build: .
    container_name: dicot_dashboard
    ports:
      - "${CONFIGURED_PORT}:${CONFIGURED_PORT}"
    volumes:
      - ./settings.json:/app/settings.json
      - ./database.sqlite:/app/database.sqlite
    environment:
      - NODE_ENV=production
    restart: always
EOF
      
      log_info "Building and launching Docker Containers..."
      docker-compose up -d --build || docker compose up -d --build
      log_success "Docker container active."
      ;;
    *)
      log_info "Skipping service startup. You can run the server manually at any time."
      ;;
  esac
}

# ------------------------------------------------------------------------------
# Main Execution Flow
# ------------------------------------------------------------------------------
main() {
  print_banner
  detect_os
  verify_dependencies
  handle_port_setup
  configure_environment
  install_and_build_project
  start_service_interactively
  
  # Success Summary
  echo -e "\n${COLOR_BOLD}${COLOR_GREEN}============================================================${COLOR_RESET}"
  echo -e "${COLOR_BOLD}${COLOR_GREEN}        DICOT DASHBOARD INSTALLED SUCCESSFULLY!             ${COLOR_RESET}"
  echo -e "${COLOR_BOLD}${COLOR_GREEN}============================================================${COLOR_RESET}"
  echo -e "  - ${COLOR_BOLD}Access Local Instance:${COLOR_RESET}  ${COLOR_CYAN}http://localhost:${CONFIGURED_PORT}${COLOR_RESET}"
  echo -e "  - ${COLOR_BOLD}Database File Location:${COLOR_RESET} ./database.sqlite"
  echo -e "  - ${COLOR_BOLD}Environment Variables:${COLOR_RESET}  ./.env"
  echo -e "  - ${COLOR_BOLD}Port Assigned:${COLOR_RESET}          ${CONFIGURED_PORT}"
  echo -e "  - ${COLOR_BOLD}Start Manually:${COLOR_RESET}         npm run start"
  echo -e "  - ${COLOR_BOLD}Dev Hot Reloading:${COLOR_RESET}      npm run dev"
  echo -e "${COLOR_BOLD}${COLOR_GREEN}============================================================${COLOR_RESET}\n"
}

main "$@"
