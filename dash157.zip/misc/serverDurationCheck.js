/**
 * Server Duration Auto-Suspend System
 * 
 * This module checks for expired servers and automatically suspends them
 * based on the configured duration settings.
 */

const fs = require("fs");
const settings = require("../settings.json");

let db = null;
let checkInterval = null;

/**
 * Initialize the duration check system
 * @param {Object} database - The Keyv database instance
 */
function initialize(database) {
  db = database;
  
  const newsettings = JSON.parse(fs.readFileSync("./settings.json").toString());
  
  if (!newsettings.api.client.serverDuration || !newsettings.api.client.serverDuration.enabled) {
    console.log("Server duration system is disabled");
    return;
  }

  const autoSuspend = newsettings.api.client.serverDuration.autoSuspend === true;
  const autoDelete = newsettings.api.client.serverDuration.autoDelete &&
    newsettings.api.client.serverDuration.autoDelete.enabled === true;

  if (!autoSuspend && !autoDelete) {
    console.log("Auto-suspend and auto-delete are both disabled");
    return;
  }

  const intervalMinutes = newsettings.api.client.serverDuration.checkIntervalMinutes || 60;
  
  console.log(`Starting server duration check system (checking every ${intervalMinutes} minutes)`);
  
  // Run immediately on startup
  checkExpiredServers();
  
  // Then run on interval
  checkInterval = setInterval(() => {
    checkExpiredServers();
  }, intervalMinutes * 60 * 1000);
}

/**
 * Check all servers for expiration and suspend if needed
 */
async function checkExpiredServers() {
  try {
    const newsettings = JSON.parse(fs.readFileSync("./settings.json").toString());
    
    if (!newsettings.api.client.serverDuration || !newsettings.api.client.serverDuration.enabled) {
      return;
    }

    console.log("Checking for expired servers...");
    
    // Fetch all servers from Pterodactyl
    const serversResponse = await fetch(
      `${newsettings.pterodactyl.domain}/api/application/servers?per_page=1000`,
      {
        method: "get",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${newsettings.pterodactyl.key}`,
        },
      }
    );

    if (!serversResponse.ok) {
      console.error("Failed to fetch servers for duration check");
      return;
    }

    const serversData = await serversResponse.json();
    const servers = serversData.data || [];
    
    const now = Date.now();
    let expiredCount = 0;
    let suspendedCount = 0;
    let deletedCount = 0;

    // Read auto-suspend / auto-delete config once for this tick
    const autoSuspendEnabled =
      newsettings.api.client.serverDuration.autoSuspend === true;
    const autoDeleteCfg = (newsettings.api.client.serverDuration.autoDelete) || {};
    const autoDeleteEnabled = autoDeleteCfg.enabled === true;
    const autoDeleteDays = Number.isFinite(Number(autoDeleteCfg.daysAfterSuspend))
      ? Number(autoDeleteCfg.daysAfterSuspend)
      : 3;
    const autoDeleteMs = Math.max(0, autoDeleteDays) * 24 * 60 * 60 * 1000;

    for (const server of servers) {
      const serverId = server.attributes.id;
      const serverName = server.attributes.name;
      const isSuspended = server.attributes.suspended;
      
      // Get server expiry date
      const expiryDate = await db.get(`server-expiry-${serverId}`);
      
      if (!expiryDate) {
        // Set default expiry if not set
        const defaultExpiry = now + (newsettings.api.client.serverDuration.defaultDays * 24 * 60 * 60 * 1000);
        await db.set(`server-expiry-${serverId}`, defaultExpiry);
        console.log(`Set default expiry for server ${serverId} (${serverName})`);
        continue;
      }
      
      // Check if expired (and not yet suspended)
      if (expiryDate <= now && !isSuspended) {
        if (!autoSuspendEnabled) {
          // Auto-suspend is disabled; skip the suspend step but leave the
          // server alone so auto-delete (if any) won't touch it either.
          continue;
        }
        expiredCount++;
        
        // Suspend the server
        const suspendResponse = await fetch(
          `${newsettings.pterodactyl.domain}/api/application/servers/${serverId}/suspend`,
          {
            method: "post",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${newsettings.pterodactyl.key}`,
            },
          }
        );

        if (suspendResponse.ok) {
          suspendedCount++;
          // Tag the suspension reason so renewal can safely auto-unsuspend
          // expired servers without overriding manual admin suspensions, and
          // record when the suspension happened so auto-delete can compute
          // the grace period.
          await db.set(`server-suspend-reason-${serverId}`, "expired");
          await db.set(`server-suspended-at-${serverId}`, now);
          console.log(`Auto-suspended expired server ${serverId} (${serverName})`);
        } else {
          console.error(`Failed to suspend expired server ${serverId} (${serverName})`);
        }
        continue;
      }

      // Auto-delete: only servers that were suspended for expiry, and only
      // after the configured grace period has elapsed.
      if (autoDeleteEnabled && isSuspended) {
        const suspendReason = await db.get(`server-suspend-reason-${serverId}`);
        if (suspendReason !== "expired") {
          // Manual admin suspensions (or untagged legacy ones) are protected.
          continue;
        }

        let suspendedAt = await db.get(`server-suspended-at-${serverId}`);
        if (!suspendedAt) {
          // Legacy server that was already suspended before we started
          // recording the timestamp — backfill with `now` so its grace
          // period starts from this tick rather than deleting immediately.
          suspendedAt = now;
          await db.set(`server-suspended-at-${serverId}`, suspendedAt);
          continue;
        }

        if (now - suspendedAt >= autoDeleteMs) {
          const deleteResponse = await fetch(
            `${newsettings.pterodactyl.domain}/api/application/servers/${serverId}`,
            {
              method: "delete",
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${newsettings.pterodactyl.key}`,
              },
            }
          );

          if (deleteResponse.ok) {
            deletedCount++;
            // Clean up our bookkeeping keys
            await db.delete(`server-expiry-${serverId}`);
            await db.delete(`server-suspend-reason-${serverId}`);
            await db.delete(`server-suspended-at-${serverId}`);
            console.log(
              `Auto-deleted suspended server ${serverId} (${serverName}) after ${autoDeleteDays}-day grace period`
            );
          } else {
            console.error(
              `Failed to auto-delete suspended server ${serverId} (${serverName}): HTTP ${deleteResponse.status}`
            );
          }
        }
      }
    }

    if (expiredCount > 0 || deletedCount > 0) {
      console.log(
        `Duration check: ${expiredCount} expired (${suspendedCount} suspended), ${deletedCount} auto-deleted`
      );
    } else {
      console.log("No expired servers found");
    }
    
  } catch (error) {
    console.error("Error checking expired servers:", error);
  }
}

/**
 * Stop the duration check system
 */
function stop() {
  if (checkInterval) {
    clearInterval(checkInterval);
    checkInterval = null;
    console.log("Server duration check system stopped");
  }
}

/**
 * Get time remaining for a server
 * @param {string} serverId - The server ID
 * @returns {Promise<Object>} Time remaining info
 */
async function getTimeRemaining(serverId) {
  const expiryDate = await db.get(`server-expiry-${serverId}`);
  
  if (!expiryDate) {
    return null;
  }
  
  const now = Date.now();
  const timeRemaining = expiryDate - now;
  const daysRemaining = Math.max(0, Math.floor(timeRemaining / (24 * 60 * 60 * 1000)));
  const hoursRemaining = Math.max(0, Math.floor(timeRemaining / (60 * 60 * 1000)));
  
  return {
    expiryDate,
    timeRemaining,
    daysRemaining,
    hoursRemaining,
    isExpired: timeRemaining <= 0
  };
}

module.exports = {
  initialize,
  stop,
  checkExpiredServers,
  getTimeRemaining
};
