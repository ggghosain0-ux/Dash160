/**
 * |-| [- |_ | /\ ( ~|~ `/ |_
 *
 * Atyro Dash v1
 *
 * This is for the frontend pages and routes.
 * @module pages
*/

const indexjs = require("../app.js");
const ejs = require("ejs");
const express = require("express");

module.exports.load = async function (app, db) {
  app.all("/", async (req, res) => {
    try {
      if (
        req.session.pterodactyl &&
        req.session.userinfo.id !== "admin" &&
        req.session.pterodactyl.id !==
          (await db.get("users-" + req.session.userinfo.id))
      ) {
        return res.redirect("/login?prompt=none");
      }

      let theme = indexjs.get(req);
      if (
        theme.settings.mustbeloggedin.includes(req._parsedUrl.pathname) &&
        (!req.session.userinfo || !req.session.pterodactyl)
      ) {
        return res.redirect("/login");
      }

      if (theme.settings.mustbeadmin.includes(req._parsedUrl.pathname)) {
        let str = await renderTemplate(
          theme,
          indexjs.renderdataeval,
          req,
          res,
          db
        );
        res.send(str);
        return;
      }

      let str = await renderTemplate(
        theme,
        indexjs.renderdataeval,
        req,
        res,
        db
      );
      res.send(str);
    } catch (err) {
      console.log(err);
      res.render("500.ejs", { err });
    }
  });

  app.use("/assets", express.static("./assets"));
};

async function renderTemplate(theme, renderdataeval, req, res, db) {
  return new Promise(async (resolve, reject) => {
    const fs = require("fs");
    const data = await eval(renderdataeval);
    const viewName = theme.settings.index;
    let ejsPath = `./views/${viewName}`;
    const activeTheme = data.activeTheme;
    const previewTheme = data.previewTheme;
    const themeToUse = previewTheme || activeTheme;
    
    if (themeToUse && themeToUse !== "default") {
      const themeEjsPath = `./themes/${themeToUse}/pages/${viewName}`;
      if (fs.existsSync(themeEjsPath)) {
        ejsPath = themeEjsPath;
      }
    }

    ejs.renderFile(
      ejsPath,
      data,
      null,
      async function (err, str) {
        if (err) {
          reject(err);
          return;
        }

        delete req.session.newaccount;
        resolve(str);
      }
    );
  });
}
