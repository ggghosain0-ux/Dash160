/**
 * |-| [- |_ | /\ ( ~|~ `/ |_
 *
 * Atyro Dash v1
 *
 * This file acts as the API for the Heliactyl application.
 * @module api
*/

const indexjs = require("../app.js");
const adminjs = require("./admin.js");
const fs = require("fs");
const ejs = require("ejs");

module.exports.load = async function (app, db) {
  /**
   * GET /api
   * Returns the status of the API.
   */
  app.get("/api", async (req, res) => {
    /* Check that the API key is valid */
    let authentication = await check(req, res);
    if (!authentication ) return;
    res.send({
      status: true,
    });
  });

  /**
   * GET /api/v2/userinfo
   * Returns the user information.
   */
  app.get("/api/v2/userinfo", async (req, res) => {
    /* Check that the API key is valid */
    let authentication = await check(req, res);
    if (!authentication ) return;

    if (!req.query.id) return res.send({ status: "missing id" });

    if (!(await db.get("users-" + req.query.id)))
      return res.send({ status: "invalid id" });

    let newsettings = JSON.parse(fs.readFileSync("./settings.json").toString());

    if (newsettings.api.client.oauth2.link.slice(-1) == "/")
      newsettings.api.client.oauth2.link =
        newsettings.api.client.oauth2.link.slice(0, -1);

    if (newsettings.api.client.oauth2.callbackpath.slice(0, 1) !== "/")
      newsettings.api.client.oauth2.callbackpath =
        "/" + newsettings.api.client.oauth2.callbackpath;

    if (newsettings.pterodactyl.domain.slice(-1) == "/")
      newsettings.pterodactyl.domain = newsettings.pterodactyl.domain.slice(
        0,
        -1
      );

    let packagename = await db.get("package-" + req.query.id);
    let package =
      newsettings.api.client.packages.list[
        packagename ? packagename : newsettings.api.client.packages.default
      ];
    if (!package)
      package = {
        ram: 0,
        disk: 0,
        cpu: 0,
        servers: 0,
      };
    package["name"] = packagename;

    let pterodactylid = await db.get("users-" + req.query.id);
    let userinforeq = await fetch(
      newsettings.pterodactyl.domain +
        "/api/application/users/" +
        pterodactylid +
        "?include=servers",
      {
        method: "get",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${newsettings.pterodactyl.key}`,
        },
      }
    );
    if ((await userinforeq.statusText) == "Not Found") {
      console.log(
        "App ― An error has occured while attempting to get a user's information"
      );
      console.log("- Discord ID: " + req.query.id);
      console.log("- Pterodactyl Panel ID: " + pterodactylid);
      return res.send({ status: "could not find user on panel" });
    }
    let userinfo = await userinforeq.json();

    res.send({
      status: "success",
      package: package,
      extra: (await db.get("extra-" + req.query.id))
        ? await db.get("extra-" + req.query.id)
        : {
            ram: 0,
            disk: 0,
            cpu: 0,
            servers: 0,
          },
      userinfo: userinfo,
      coins:
        newsettings.api.client.coins.enabled == true
          ? (await db.get("coins-" + req.query.id))
            ? await db.get("coins-" + req.query.id)
            : 0
          : null,
    });
  });

  /**
   * POST /api/v2/setcoins
   * Sets the number of coins for a user.
   */
  app.post("/api/v2/setcoins", async (req, res) => {
    /* Check that the API key is valid */
    let authentication = await check(req, res);
    if (!authentication ) return;

    if (typeof req.body !== "object")
      return res.send({ status: "body must be an object" });
    if (Array.isArray(req.body))
      return res.send({ status: "body cannot be an array" });
    let id = req.body.id;
    let coins = req.body.coins;
    if (typeof id !== "string")
      return res.send({ status: "id must be a string" });
    if (!(await db.get("users-" + id)))
      return res.send({ status: "invalid id" });
    if (typeof coins !== "number")
      return res.send({ status: "coins must be number" });
    if (coins < 0 || coins > 999999999999999)
      return res.send({ status: "too small or big coins" });
    if (coins == 0) {
      await db.delete("coins-" + id);
    } else {
      await db.set("coins-" + id, coins);
    }
    res.send({ status: "success" });
  });

  /**
   * POST /api/v2/setplan
   * Sets the plan for a user.
   */
  app.post("/api/v2/setplan", async (req, res) => {
    /* Check that the API key is valid */
    let authentication = await check(req, res);
    if (!authentication ) return;

    if (!req.body) return res.send({ status: "missing body" });

    if (typeof req.body.id !== "string")
      return res.send({ status: "missing id" });

    if (!(await db.get("users-" + req.body.id)))
      return res.send({ status: "invalid id" });

    if (typeof req.body.package !== "string") {
      await db.delete("package-" + req.body.id);
      adminjs.suspend(req.body.id);
      return res.send({ status: "success" });
    } else {
      let newsettings = JSON.parse(
        fs.readFileSync("./settings.json").toString()
      );
      if (!newsettings.api.client.packages.list[req.body.package])
        return res.send({ status: "invalid package" });
      await db.set("package-" + req.body.id, req.body.package);
      adminjs.suspend(req.body.id);
      return res.send({ status: "success" });
    }
  });

  /**
   * POST /api/v2/setresources
   * Sets the resources for a user.
   */
  app.post("/api/v2/setresources", async (req, res) => {
    /* Check that the API key is valid */
    let authentication = await check(req, res);
    if (!authentication ) return;

    if (!req.body) return res.send({ status: "missing body" });

    if (typeof req.body.id !== "string")
      return res.send({ status: "missing id" });

    if (!(await db.get("users-" + req.body.id)))
      res.send({ status: "invalid id" });

    if (
      typeof req.body.ram == "number" ||
      typeof req.body.disk == "number" ||
      typeof req.body.cpu == "number" ||
      typeof req.body.servers == "number"
    ) {
      let ram = req.body.ram;
      let disk = req.body.disk;
      let cpu = req.body.cpu;
      let servers = req.body.servers;

      let currentextra = await db.get("extra-" + req.body.id);
      let extra;

      if (typeof currentextra == "object") {
        extra = currentextra;
      } else {
        extra = {
          ram: 0,
          disk: 0,
          cpu: 0,
          servers: 0,
        };
      }

      if (typeof ram == "number") {
        if (ram < 0 || ram > 999999999999999) {
          return res.send({ status: "ram size" });
        }
        extra.ram = ram;
      }

      if (typeof disk == "number") {
        if (disk < 0 || disk > 999999999999999) {
          return res.send({ status: "disk size" });
        }
        extra.disk = disk;
      }

      if (typeof cpu == "number") {
        if (cpu < 0 || cpu > 999999999999999) {
          return res.send({ status: "cpu size" });
        }
        extra.cpu = cpu;
      }

      if (typeof servers == "number") {
        if (servers < 0 || servers > 999999999999999) {
          return res.send({ status: "server size" });
        }
        extra.servers = servers;
      }

      if (
        extra.ram == 0 &&
        extra.disk == 0 &&
        extra.cpu == 0 &&
        extra.servers == 0
      ) {
        await db.delete("extra-" + req.body.id);
      } else {
        await db.set("extra-" + req.body.id, extra);
      }

      adminjs.suspend(req.body.id);
      return res.send({ status: "success" });
    } else {
      res.send({ status: "missing variables" });
    }
  });

  /**
   * Checks the authorization and returns the settings if authorized.
   * Renders the file based on the theme and sends the response.
   * @param {Object} req - The request object.
   * @param {Object} res - The response object.
   * @returns {Object|null} - The settings object if authorized, otherwise null.
   */
  async function check(req, res) {
    let settings = JSON.parse(fs.readFileSync("./settings.json").toString());
    if (settings.api.client.api.enabled == true) {
      let auth = req.headers["authorization"];
      if (auth) {
        if (auth == "Bearer " + settings.api.client.api.code) {
          return settings;
        }
      }
    }
    let theme = indexjs.get(req);
    ejs.renderFile(
      `./views/${theme.settings.notfound}`,
      await eval(indexjs.renderdataeval),
      null,
      function (err, str) {
        delete req.session.newaccount;
        if (err) {
          console.log(
            `App ― An error has occured on path ${req._parsedUrl.pathname}:`
          );
          console.log(err);
          return res.send(
            "Internal Server Error"
          );
        }
        res.status(200);
        res.send(str);
      }
    );
    return null;
  }

  /**
   * GET /api/afk/streak
   * Get user's AFK streak
   */
  app.get("/api/afk/streak", async (req, res) => {
    if (!req.session.userinfo) {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const streak = await db.get(`afk-streak-${req.session.userinfo.id}`) || 0;
      const lastEarnTime = await db.get(`afk-last-earn-${req.session.userinfo.id}`) || Date.now();
      
      res.json({
        streak: streak,
        lastEarnTime: lastEarnTime
      });
    } catch (error) {
      console.error("Error getting AFK streak:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  /**
   * POST /api/afk/streak
   * Save user's AFK streak
   */
  app.post("/api/afk/streak", async (req, res) => {
    if (!req.session.userinfo) {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const { streak, lastEarnTime } = req.body;
      
      await db.set(`afk-streak-${req.session.userinfo.id}`, streak || 0);
      await db.set(`afk-last-earn-${req.session.userinfo.id}`, lastEarnTime || Date.now());
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error saving AFK streak:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  /**
   * POST /api/coupon/redeem
   * Redeem a coupon code
   */
  app.post("/api/coupon/redeem", async (req, res) => {
    if (!req.session.userinfo) {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const { code } = req.body;
      
      if (!code || typeof code !== 'string') {
        return res.status(400).json({ error: "Invalid coupon code" });
      }

      const couponCode = code.toUpperCase().trim();
      
      // Get coupon data
      const coupon = await db.get(`coupon-${couponCode}`);
      
      if (!coupon) {
        return res.status(404).json({ error: "Coupon not found or expired" });
      }

      // Check if coupon has expired
      if (coupon.expiresAt && Date.now() > coupon.expiresAt) {
        await db.delete(`coupon-${couponCode}`);
        return res.status(400).json({ error: "Coupon has expired" });
      }

      // Check if user has already used this coupon
      const usedCoupons = await db.get(`used-coupons-${req.session.userinfo.id}`) || [];
      if (usedCoupons.includes(couponCode)) {
        return res.status(400).json({ error: "You have already used this coupon" });
      }

      // Add coins to user
      const currentCoins = await db.get(`coins-${req.session.userinfo.id}`) || 0;
      await db.set(`coins-${req.session.userinfo.id}`, currentCoins + coupon.coins);

      // Mark coupon as used by this user
      usedCoupons.push(couponCode);
      await db.set(`used-coupons-${req.session.userinfo.id}`, usedCoupons);

      // Increment usage count
      coupon.usedCount = (coupon.usedCount || 0) + 1;
      
      // Check if coupon has reached max uses
      if (coupon.maxUses && coupon.usedCount >= coupon.maxUses) {
        await db.delete(`coupon-${couponCode}`);
      } else {
        await db.set(`coupon-${couponCode}`, coupon);
      }

      res.json({
        success: true,
        coins: coupon.coins,
        newBalance: currentCoins + coupon.coins
      });
    } catch (error) {
      console.error("Error redeeming coupon:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });
};
