/**
 * |-| [- |_ | /\ ( ~|~ `/ |_
 *
 * Atyro Dash v1
 *
 * This is for miscellaneous extra endpoints.
 * @module extras
 */

const settings = require("../settings.json");
const fs = require("fs");
const indexjs = require("../app.js");
const fetch = require("node-fetch");
const Queue = require("../managers/Queue");

module.exports.load = async function (app, db) {
  app.get("/panel", async (req, res) => {
    res.redirect(settings.pterodactyl.domain);
  });

  app.get("/regen", async (req, res) => {
    if (!req.session.pterodactyl) return res.redirect("/login");

    let newsettings = JSON.parse(fs.readFileSync("./settings.json"));

    if (newsettings.api.client.allow.regen !== true)
      return res.send("You cannot regenerate your password currently.");

    let newpassword = makeid(
      newsettings.api.client.passwordgenerator["length"]
    );
    req.session.password = newpassword;

    await fetch(
      settings.pterodactyl.domain +
        "/api/application/users/" +
        req.session.pterodactyl.id,
      {
        method: "patch",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${settings.pterodactyl.key}`,
        },
        body: JSON.stringify({
          username: req.session.pterodactyl.username,
          email: req.session.pterodactyl.email,
          first_name: req.session.pterodactyl.first_name,
          last_name: req.session.pterodactyl.last_name,
          password: newpassword,
        }),
      }
    );

    let theme = indexjs.get(req);
    res.redirect("/security");
  });

  /* Create a Queue */
  const queue = new Queue();

  /**
   * Resolve a recipient to the dashboard's internal Discord user ID.
   * Supports three lookup modes:
   *   - "discord"  → recipient is already a Discord ID
   *   - "email"    → look up the Pterodactyl user by email, then read its
   *                  `username` field (the dashboard stores the Discord ID
   *                  there during account creation, see api/oauth2.js).
   *   - "username" → same as email lookup but via Pterodactyl username
   *                  (which is the Discord ID — useful as a fallback).
   * Returns { discordId, pteroId } on success, or { error } on failure.
   */
  async function resolveRecipient(recipient, type) {
    const newsettings = JSON.parse(fs.readFileSync("./settings.json").toString());
    const value = (recipient || "").toString().trim();

    if (!value) return { error: "MISSINGFIELDS" };

    const mode = (type || "").toString().toLowerCase();

    // Auto-detect when no/unknown type was given
    let detected = mode;
    if (!["discord", "email", "username"].includes(detected)) {
      if (value.includes("@")) detected = "email";
      else if (/^\d{15,25}$/.test(value)) detected = "discord";
      else detected = "username";
    }

    if (detected === "discord") {
      // Verify a coins record exists for that Discord ID
      const existing = await db.get(`coins-${value}`);
      const linked = await db.get(`users-${value}`);
      if (existing === undefined && linked === undefined) {
        return { error: "USERDOESNTEXIST" };
      }
      return { discordId: value, pteroId: linked || null };
    }

    // email or username lookup via Pterodactyl Application API
    const filterKey = detected === "email" ? "email" : "username";
    try {
      const resp = await fetch(
        `${newsettings.pterodactyl.domain}/api/application/users?filter[${filterKey}]=${encodeURIComponent(value)}`,
        {
          method: "get",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${newsettings.pterodactyl.key}`,
          },
        }
      );
      if (!resp.ok) return { error: "USERDOESNTEXIST" };
      const data = await resp.json();
      const matches = (data.data || []).filter((u) =>
        detected === "email"
          ? (u.attributes.email || "").toLowerCase() === value.toLowerCase()
          : u.attributes.username === value
      );
      if (matches.length !== 1) return { error: "USERDOESNTEXIST" };

      const attrs = matches[0].attributes;
      // The dashboard sets pterodactyl `username` to the Discord ID on signup.
      const discordId = attrs.username;
      const linked = await db.get(`users-${discordId}`);
      if (linked === undefined) return { error: "USERDOESNTEXIST" };
      return { discordId, pteroId: attrs.id };
    } catch (e) {
      console.error("resolveRecipient error:", e);
      return { error: "USERDOESNTEXIST" };
    }
  }

  // Legacy GET endpoint — kept for backwards compatibility
  app.get("/transfercoins", async (req, res) => {
    if (!req.session.pterodactyl) return res.redirect(`/`);

    const coins = parseInt(req.query.coins);
    if (!coins || !req.query.id)
      return res.redirect(`/transfer?err=MISSINGFIELDS`);
    if (req.query.id.includes(`${req.session.userinfo.id}`))
      return res.redirect(`/transfer?err=CANNOTGIFTYOURSELF`);

    if (coins < 1) return res.redirect(`/transfer?err=TOOLOWCOINS`);

    queue.addJob(async (cb) => {
      const usercoins = await db.get(`coins-${req.session.userinfo.id}`);
      const othercoins = await db.get(`coins-${req.query.id}`);
      if (othercoins === undefined) {
        cb();
        return res.redirect(`/transfer?err=USERDOESNTEXIST`);
      }
      if (usercoins < coins) {
        cb();
        return res.redirect(`/transfer?err=CANTAFFORD`);
      }

      await db.set(`coins-${req.query.id}`, othercoins + coins);
      await db.set(`coins-${req.session.userinfo.id}`, usercoins - coins);

      log(
        "Gifted Coins",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} sent ${coins}\ coins to the user with the ID \`${req.query.id}\`.`
      );
      cb();
      return res.redirect(`/transfer?err=none`);
    });
  });

  /**
   * New form/JSON endpoint used by views/coins/transfer.ejs.
   * Accepts (form-urlencoded or JSON):
   *   - recipient     (Discord ID, email, or Pterodactyl username)
   *   - recipientType ("discord" | "email" | "username" | "auto")
   *   - amount        (number of coins to send)
   */
  app.post("/api/transfer", async (req, res) => {
    if (!req.session.pterodactyl) return res.redirect("/login");

    const recipient = (req.body.recipient || "").toString().trim();
    const recipientType = (req.body.recipientType || "auto").toString();
    const amount = Math.floor(Number(req.body.amount));

    if (!recipient || !amount || isNaN(amount)) {
      return res.redirect(`/transfer?err=MISSINGFIELDS`);
    }
    if (amount < 1) {
      return res.redirect(`/transfer?err=TOOLOWCOINS`);
    }

    const resolved = await resolveRecipient(recipient, recipientType);
    if (resolved.error) {
      return res.redirect(`/transfer?err=${resolved.error}`);
    }

    if (resolved.discordId === `${req.session.userinfo.id}`) {
      return res.redirect(`/transfer?err=CANNOTGIFTYOURSELF`);
    }

    queue.addJob(async (cb) => {
      try {
        const usercoins = (await db.get(`coins-${req.session.userinfo.id}`)) || 0;
        const othercoins = (await db.get(`coins-${resolved.discordId}`)) || 0;

        if (usercoins < amount) {
          cb();
          return res.redirect(`/transfer?err=CANTAFFORD`);
        }

        await db.set(`coins-${resolved.discordId}`, othercoins + amount);
        await db.set(`coins-${req.session.userinfo.id}`, usercoins - amount);

        log(
          "Gifted Coins",
          `${req.session.userinfo.username}#${req.session.userinfo.discriminator} sent ${amount} coins to user \`${resolved.discordId}\` (via ${recipientType}).`
        );
        cb();
        return res.redirect(`/transfer?err=TRANSFERRED&num=${amount}`);
      } catch (e) {
        console.error("Transfer error:", e);
        cb();
        return res.redirect(`/transfer?err=USERDOESNTEXIST`);
      }
    });
  });
};

function makeid(length) {
  let result = "";
  let characters =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let charactersLength = characters.length;
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}
