/**
 * |-| [- |_ | /\ ( ~|~ `/ |_
 *
 * Atyro Dash v1
 *
 * This is for creating, deleting and editing servers on the user side.
 * @module servers
*/

const settings = require("../settings.json");
const indexjs = require("../app.js");
const adminjs = require("./admin.js");
const fs = require("fs");
const getPteroUser = require("../misc/getPteroUser");
const Queue = require("../managers/Queue");
const log = require("../misc/log");

if (settings.pterodactyl)
  if (settings.pterodactyl.domain) {
    if (settings.pterodactyl.domain.slice(-1) == "/")
      settings.pterodactyl.domain = settings.pterodactyl.domain.slice(0, -1);
  }

module.exports.load = async function (app, db) {
  // API endpoint to get detailed server info with egg and node names
  app.get("/api/servers/info/:serverId", async (req, res) => {
    if (!req.session.pterodactyl) {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const serverId = req.params.serverId;
      const newsettings = JSON.parse(fs.readFileSync("./settings.json").toString());
      
      // Check if user owns this server
      const serverExists = req.session.pterodactyl.relationships.servers.data.find(
        s => s.attributes.id.toString() === serverId
      );
      
      if (!serverExists) {
        return res.status(404).json({ error: "Server not found" });
      }

      // Fetch full server details from Pterodactyl
      const serverResponse = await fetch(
        `${newsettings.pterodactyl.domain}/api/application/servers/${serverId}?include=egg,node`,
        {
          method: "get",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${newsettings.pterodactyl.key}`,
          },
        }
      );

      if (!serverResponse.ok) {
        return res.status(500).json({ error: "Failed to fetch server details" });
      }

      const serverData = await serverResponse.json();
      const server = serverData.attributes;
      
      // Extract egg and node information
      let eggName = "Unknown";
      let nodeName = "Unknown";
      
      if (serverData.attributes.relationships) {
        if (serverData.attributes.relationships.egg && serverData.attributes.relationships.egg.attributes) {
          eggName = serverData.attributes.relationships.egg.attributes.name;
        }
        if (serverData.attributes.relationships.node && serverData.attributes.relationships.node.attributes) {
          nodeName = serverData.attributes.relationships.node.attributes.name;
        }
      }

      res.json({
        server: {
          id: server.id,
          name: server.name,
          description: server.description,
          suspended: server.suspended,
          limits: server.limits,
          eggName: eggName,
          nodeName: nodeName,
          egg: server.egg,
          node: server.node
        }
      });
    } catch (error) {
      console.error("Error fetching server info:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // API endpoint to get user coins
  app.get("/api/user/coins", async (req, res) => {
    if (!req.session.pterodactyl) {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const coins = await db.get("coins-" + req.session.userinfo.id) || 0;
      res.json({ coins: coins });
    } catch (error) {
      console.error("Error fetching user coins:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // API endpoint to get server duration info
  app.get("/api/servers/duration/:serverId", async (req, res) => {
    if (!req.session.pterodactyl) {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const serverId = req.params.serverId;
      const newsettings = JSON.parse(fs.readFileSync("./settings.json").toString());
      
      // Admins can view duration for any server; otherwise enforce ownership
      const isAdmin = !!(req.session.pterodactyl && req.session.pterodactyl.root_admin);
      if (!isAdmin) {
        const serverExists = req.session.pterodactyl.relationships.servers.data.find(
          s => s.attributes.id.toString() === serverId
        );
        
        if (!serverExists) {
          return res.status(404).json({ error: "Server not found" });
        }
      }

      // Get server expiry date
      const expiryDate = await db.get(`server-expiry-${serverId}`);
      const now = Date.now();

      // Safe access to serverDuration config with sensible defaults
      const sd =
        (newsettings.api &&
          newsettings.api.client &&
          newsettings.api.client.serverDuration) || {};
      const defaultDays = Number(sd.defaultDays) > 0 ? Number(sd.defaultDays) : 7;
      const renewalCostPerDay =
        Number(sd.renewalCostPerDay) >= 0 ? Number(sd.renewalCostPerDay) : 0;

      if (!expiryDate) {
        // Set default expiry if not set
        const defaultExpiry = now + (defaultDays * 24 * 60 * 60 * 1000);
        await db.set(`server-expiry-${serverId}`, defaultExpiry);
        
        return res.json({
          serverId: serverId,
          expiryDate: defaultExpiry,
          daysRemaining: defaultDays,
          hoursRemaining: defaultDays * 24,
          isExpired: false,
          renewalCostPerDay: renewalCostPerDay
        });
      }
      
      const timeRemaining = expiryDate - now;
      const daysRemaining = Math.max(0, Math.floor(timeRemaining / (24 * 60 * 60 * 1000)));
      const hoursRemaining = Math.max(0, Math.floor(timeRemaining / (60 * 60 * 1000)));
      
      res.json({
        serverId: serverId,
        expiryDate: expiryDate,
        daysRemaining: daysRemaining,
        hoursRemaining: hoursRemaining,
        isExpired: timeRemaining <= 0,
        renewalCostPerDay: renewalCostPerDay
      });
    } catch (error) {
      console.error("Error fetching server duration:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // API endpoint to renew server
  app.post("/api/servers/renew", async (req, res) => {
    if (!req.session.pterodactyl) {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const { serverId, days } = req.body;
      
      if (!serverId || !days || days < 1) {
        return res.status(400).json({ error: "Invalid request" });
      }

      const newsettings = JSON.parse(fs.readFileSync("./settings.json").toString());
      
      // Check if user owns this server
      const serverExists = req.session.pterodactyl.relationships.servers.data.find(
        s => s.attributes.id.toString() === serverId.toString()
      );
      
      if (!serverExists) {
        return res.status(404).json({ error: "Server not found" });
      }

      // Calculate cost
      const cost = days * newsettings.api.client.serverDuration.renewalCostPerDay;
      
      // Get user coins
      const userCoins = await db.get("coins-" + req.session.userinfo.id) || 0;
      
      if (userCoins < cost) {
        return res.status(400).json({ 
          error: "Insufficient coins",
          required: cost,
          available: userCoins
        });
      }

      // Deduct coins
      await db.set("coins-" + req.session.userinfo.id, userCoins - cost);
      
      // Get current expiry or set to now if expired
      const currentExpiry = await db.get(`server-expiry-${serverId}`) || Date.now();
      const now = Date.now();
      const baseTime = currentExpiry > now ? currentExpiry : now;
      const wasExpired = currentExpiry <= now;
      
      // Add days to expiry
      const newExpiry = baseTime + (days * 24 * 60 * 60 * 1000);
      await db.set(`server-expiry-${serverId}`, newExpiry);
      
      // If the server is currently suspended for expiry, auto-unsuspend it.
      // We skip this if the suspension reason is "manual" (admin suspended for
      // abuse etc.) so a renewal cannot bypass a deliberate admin action.
      let wasSuspended = false;
      let unsuspended = false;
      let unsuspendError = null;

      const serverInfo = await fetch(
        `${newsettings.pterodactyl.domain}/api/application/servers/${serverId}`,
        {
          method: "get",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${newsettings.pterodactyl.key}`,
          },
        }
      );

      if (serverInfo.ok) {
        const serverData = await serverInfo.json();
        wasSuspended = !!serverData.attributes.suspended;

        if (wasSuspended) {
          const suspendReason = await db.get(`server-suspend-reason-${serverId}`);
          // Auto-unsuspend when:
          //   - reason is explicitly "expired" (set by the cron), OR
          //   - reason is unset/legacy AND the prior expiry was in the past
          //     (best-effort backwards compat for servers suspended before
          //     reason tracking was added).
          const safeToUnsuspend =
            suspendReason === "expired" ||
            (!suspendReason && wasExpired);

          if (safeToUnsuspend) {
            const unsuspendResp = await fetch(
              `${newsettings.pterodactyl.domain}/api/application/servers/${serverId}/unsuspend`,
              {
                method: "post",
                headers: {
                  "Content-Type": "application/json",
                  Authorization: `Bearer ${newsettings.pterodactyl.key}`,
                },
              }
            );

            if (unsuspendResp.ok) {
              unsuspended = true;
              await db.delete(`server-suspend-reason-${serverId}`);
            } else {
              unsuspendError = `Pterodactyl returned ${unsuspendResp.status}`;
              console.error(
                `Failed to unsuspend server ${serverId} after renewal: ${unsuspendError}`
              );
            }
          } else {
            unsuspendError =
              "Server was suspended by an administrator; please contact support to have it unsuspended.";
          }
        }
      } else {
        unsuspendError = `Failed to fetch server status (Pterodactyl returned ${serverInfo.status})`;
        console.error(unsuspendError);
      }
      
      log(
        "renewed server",
        `${req.session.userinfo.username}#${req.session.userinfo.discriminator} renewed server ${serverId} for ${days} days (Cost: ${cost} coins, wasSuspended=${wasSuspended}, unsuspended=${unsuspended})`
      );
      
      res.json({
        success: true,
        newExpiry: newExpiry,
        coinsRemaining: userCoins - cost,
        daysAdded: days,
        wasSuspended,
        unsuspended,
        unsuspendError
      });
    } catch (error) {
      console.error("Error renewing server:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // API endpoint to fetch available nodes and eggs
  app.get("/api/servers/options", async (req, res) => {
    if (!req.session.pterodactyl) {
      return res.status(403).json({ error: "Unauthorized" });
    }

    try {
      const newsettings = JSON.parse(fs.readFileSync("./settings.json").toString());
      
      // Fetch all nodes from Pterodactyl
      const nodesResponse = await fetch(
        `${newsettings.pterodactyl.domain}/api/application/nodes`,
        {
          method: "get",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${newsettings.pterodactyl.key}`,
          },
        }
      );

      if (!nodesResponse.ok) {
        console.error("Failed to fetch nodes:", nodesResponse.statusText);
        return res.status(500).json({ error: "Failed to fetch nodes" });
      }

      const nodesData = await nodesResponse.json();
      const nodes = nodesData.data.map(node => ({
        id: node.attributes.id,
        name: node.attributes.name,
        location_id: node.attributes.location_id,
        fqdn: node.attributes.fqdn,
        memory: node.attributes.memory,
        disk: node.attributes.disk,
        allocated_memory: node.attributes.allocated_resources?.memory || 0,
        allocated_disk: node.attributes.allocated_resources?.disk || 0,
      }));

      // Resolve location names so the create form can display them next to
      // each node (helps users when many nodes share or differ by location).
      let locationsMap = {};
      try {
        const locResp = await fetch(
          `${newsettings.pterodactyl.domain}/api/application/locations?per_page=200`,
          {
            method: "get",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${newsettings.pterodactyl.key}`,
            },
          }
        );
        if (locResp.ok) {
          const locJson = await locResp.json();
          (locJson.data || []).forEach(l => {
            locationsMap[l.attributes.id] = l.attributes.short || l.attributes.long || ("Location " + l.attributes.id);
          });
        }
      } catch (e) {
        console.error("Failed to fetch locations list:", e);
      }
      nodes.forEach(n => {
        n.location_name = locationsMap[n.location_id] || ("Location " + n.location_id);
      });

      // Fetch all eggs from Pterodactyl
      const nestsResponse = await fetch(
        `${newsettings.pterodactyl.domain}/api/application/nests`,
        {
          method: "get",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${newsettings.pterodactyl.key}`,
          },
        }
      );

      if (!nestsResponse.ok) {
        console.error("Failed to fetch nests:", nestsResponse.statusText);
        return res.status(500).json({ error: "Failed to fetch nests" });
      }

      const nestsData = await nestsResponse.json();
      const eggs = [];

      // For each nest, fetch its eggs
      for (const nest of nestsData.data) {
        const eggsResponse = await fetch(
          `${newsettings.pterodactyl.domain}/api/application/nests/${nest.attributes.id}/eggs`,
          {
            method: "get",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${newsettings.pterodactyl.key}`,
            },
          }
        );

        if (eggsResponse.ok) {
          const eggsData = await eggsResponse.json();
          eggsData.data.forEach(egg => {
            eggs.push({
              id: egg.attributes.id,
              nest_id: nest.attributes.id,
              nest_name: nest.attributes.name,
              name: egg.attributes.name,
              description: egg.attributes.description,
              docker_image: egg.attributes.docker_image,
            });
          });
        }
      }

      // Get user's package and resources
      const packagename = await db.get("package-" + req.session.userinfo.id);
      const package = newsettings.api.client.packages.list[
        packagename ? packagename : newsettings.api.client.packages.default
      ];

      const extra = (await db.get("extra-" + req.session.userinfo.id)) || {
        ram: 0,
        disk: 0,
        cpu: 0,
        servers: 0,
        backups: 0,
        databases: 0,
        allocations: 0,
      };
      // Backfill missing fields for legacy users
      if (typeof extra.backups !== "number") extra.backups = 0;
      if (typeof extra.databases !== "number") extra.databases = 0;
      if (typeof extra.allocations !== "number") extra.allocations = 0;

      // Calculate used resources
      let ram = 0;
      let disk = 0;
      let cpu = 0;
      let backupsUsed = 0;
      let databasesUsed = 0;
      let allocationsUsed = 0;
      let servers = req.session.pterodactyl.relationships.servers.data.length;
      
      for (let i = 0, len = req.session.pterodactyl.relationships.servers.data.length; i < len; i++) {
        const s = req.session.pterodactyl.relationships.servers.data[i].attributes;
        ram += s.limits.memory || 0;
        disk += s.limits.disk || 0;
        cpu += s.limits.cpu || 0;
        backupsUsed += (s.feature_limits && s.feature_limits.backups) || 0;
        databasesUsed += (s.feature_limits && s.feature_limits.databases) || 0;
        allocationsUsed += (s.feature_limits && s.feature_limits.allocations) || 0;
      }

      // Backups/databases/allocations defaults if package doesn't define them
      const pkgBackups = typeof package.backups === "number" ? package.backups : 1;
      const pkgDatabases = typeof package.databases === "number" ? package.databases : 1;
      const pkgAllocations = typeof package.allocations === "number" ? package.allocations : 1;

      res.json({
        nodes: nodes,
        eggs: eggs,
        resources: {
          available: {
            ram: (package.ram + extra.ram - ram) / 1024, // Convert to GB
            disk: (package.disk + extra.disk - disk) / 1024, // Convert to GB
            cpu: (package.cpu + extra.cpu - cpu) / 100, // Convert to cores
            servers: package.servers + extra.servers - servers,
            backups: pkgBackups + extra.backups - backupsUsed,
            databases: pkgDatabases + extra.databases - databasesUsed,
            allocations: pkgAllocations + extra.allocations - allocationsUsed,
          },
          total: {
            ram: (package.ram + extra.ram) / 1024,
            disk: (package.disk + extra.disk) / 1024,
            cpu: (package.cpu + extra.cpu) / 100,
            servers: package.servers + extra.servers,
            backups: pkgBackups + extra.backups,
            databases: pkgDatabases + extra.databases,
            allocations: pkgAllocations + extra.allocations,
          },
          used: {
            ram: ram / 1024,
            disk: disk / 1024,
            cpu: cpu / 100,
            servers: servers,
            backups: backupsUsed,
            databases: databasesUsed,
            allocations: allocationsUsed,
          }
        }
      });
    } catch (error) {
      console.error("Error fetching server options:", error);
      res.status(500).json({ error: "Internal server error", message: error.message });
    }
  });

  app.get("/updateinfo", async (req, res) => {
    if (!req.session.pterodactyl) return res.redirect("/login");
    const cacheaccount = await getPteroUser(req.session.userinfo.id, db).catch(
      () => {
        return res.send(
          "An error has occured while attempting to update your account information and server list."
        );
      }
    );
    if (!cacheaccount) return;
    req.session.pterodactyl = cacheaccount.attributes;
    if (req.query.redirect)
      if (typeof req.query.redirect == "string")
        return res.redirect("/" + req.query.redirect);
    res.redirect("/servers");
  });

  const queue = new Queue();
  app.get("/create", async (req, res) => {
    if (!req.session.pterodactyl) return res.redirect("/login");

    let theme = indexjs.get(req);

    let newsettings = JSON.parse(fs.readFileSync("./settings.json").toString());
    if (newsettings.api.client.allow.server.create == true) {
      queue.addJob(async (cb) => {
        let redirectlink = theme.settings.redirect.failedcreateserver ?? "/"; // fail redirect link

        const cacheaccount = await getPteroUser(
          req.session.userinfo.id,
          db
        ).catch(() => {
          cb();
          return res.send(
            "An error has occured while attempting to update your account information and server list."
          );
        });
        if (!cacheaccount) {
          cb();
          return res.send(
            "Heliactyl failed to find an account on the configured panel, try relogging"
          );
        }
        req.session.pterodactyl = cacheaccount.attributes;

        if (
          req.query.name &&
          req.query.ram &&
          req.query.disk &&
          req.query.cpu &&
          req.query.egg &&
          req.query.location
        ) {
          try {
            decodeURIComponent(req.query.name);
          } catch (err) {
            cb();
            return res.redirect(`${redirectlink}?err=COULDNOTDECODENAME`);
          }

          let packagename = await db.get("package-" + req.session.userinfo.id);
          let package =
            newsettings.api.client.packages.list[
              packagename
                ? packagename
                : newsettings.api.client.packages.default
            ];

          let extra = (await db.get("extra-" + req.session.userinfo.id)) || {
            ram: 0,
            disk: 0,
            cpu: 0,
            servers: 0,
            backups: 0,
            databases: 0,
            allocations: 0,
          };
          if (typeof extra.backups !== "number") extra.backups = 0;
          if (typeof extra.databases !== "number") extra.databases = 0;
          if (typeof extra.allocations !== "number") extra.allocations = 0;

          let ram2 = 0;
          let disk2 = 0;
          let cpu2 = 0;
          let backups2 = 0;
          let databases2 = 0;
          let allocations2 = 0;
          let servers2 =
            req.session.pterodactyl.relationships.servers.data.length;
          for (
            let i = 0,
              len = req.session.pterodactyl.relationships.servers.data.length;
            i < len;
            i++
          ) {
            const s = req.session.pterodactyl.relationships.servers.data[i].attributes;
            ram2 = ram2 + (s.limits.memory || 0);
            disk2 = disk2 + (s.limits.disk || 0);
            cpu2 = cpu2 + (s.limits.cpu || 0);
            backups2 = backups2 + ((s.feature_limits && s.feature_limits.backups) || 0);
            databases2 = databases2 + ((s.feature_limits && s.feature_limits.databases) || 0);
            allocations2 = allocations2 + ((s.feature_limits && s.feature_limits.allocations) || 0);
          }

          if (servers2 >= package.servers + extra.servers) {
            cb();
            return res.redirect(`${redirectlink}?err=TOOMUCHSERVERS`);
          }

          let name = decodeURIComponent(req.query.name);
          if (name.length < 1) {
            cb();
            return res.redirect(`${redirectlink}?err=LITTLESERVERNAME`);
          }
          if (name.length > 191) {
            cb();
            return res.redirect(`${redirectlink}?err=BIGSERVERNAME`);
          }

          let location = req.query.location;

          // The frontend (views/servers/create.ejs) lets the user choose a
          // Pterodactyl node fetched live from the panel. Validate against the
          // real panel data instead of the (often empty) static
          // newsettings.api.client.locations map. We also need the actual
          // Pterodactyl location_id for deploy.locations (the API expects
          // location IDs there, not node IDs).
          let deployLocationId = null;
          let matchedNodeId = null;
          try {
            const nodesResp = await fetch(
              `${newsettings.pterodactyl.domain}/api/application/nodes`,
              {
                method: "get",
                headers: {
                  "Content-Type": "application/json",
                  Authorization: `Bearer ${newsettings.pterodactyl.key}`,
                },
              }
            );
            if (!nodesResp.ok) {
              cb();
              return res.redirect(`${redirectlink}?err=INVALIDLOCATION`);
            }
            const nodesJson = await nodesResp.json();
            const selectedIdNum = parseInt(location);
            // First try to interpret the selection as a node ID (this is what
            // the create.ejs form sends today).
            const matchedNode = nodesJson.data.find(
              (n) => n.attributes.id === selectedIdNum
            );
            if (matchedNode) {
              matchedNodeId = matchedNode.attributes.id;
              deployLocationId = matchedNode.attributes.location_id;
            } else {
              // Fall back: maybe the selection is already a location ID (e.g.
              // legacy clients or admins using settings.json locations).
              const nodeInLocation = nodesJson.data.find(
                (n) => n.attributes.location_id === selectedIdNum
              );
              if (nodeInLocation) {
                deployLocationId = selectedIdNum;
              }
            }
          } catch (e) {
            console.error("Failed to validate location against panel:", e);
            cb();
            return res.redirect(`${redirectlink}?err=INVALIDLOCATION`);
          }

          if (deployLocationId === null) {
            cb();
            return res.redirect(`${redirectlink}?err=INVALIDLOCATION`);
          }

          // If the user picked a specific node, find a free allocation ON THAT
          // NODE so we can deploy directly there. Pterodactyl's
          // deploy.locations only takes LOCATION ids and lets the panel pick
          // any node in those locations — that's why selecting "Node 2" was
          // ending up on "Node 1" when both shared a location. Using
          // allocation.default forces the exact node.
          let chosenAllocationId = null;
          if (matchedNodeId !== null) {
            try {
              let page = 1;
              const maxPages = 50; // safety cap
              while (page <= maxPages && chosenAllocationId === null) {
                const allocResp = await fetch(
                  `${newsettings.pterodactyl.domain}/api/application/nodes/${matchedNodeId}/allocations?per_page=200&page=${page}`,
                  {
                    method: "get",
                    headers: {
                      "Content-Type": "application/json",
                      Authorization: `Bearer ${newsettings.pterodactyl.key}`,
                    },
                  }
                );
                if (!allocResp.ok) break;
                const allocJson = await allocResp.json();
                const freeAlloc = (allocJson.data || []).find(
                  (a) => a && a.attributes && a.attributes.assigned === false
                );
                if (freeAlloc) {
                  chosenAllocationId = freeAlloc.attributes.id;
                  break;
                }
                const totalPages =
                  (allocJson.meta &&
                    allocJson.meta.pagination &&
                    allocJson.meta.pagination.total_pages) ||
                  1;
                if (page >= totalPages) break;
                page++;
              }
            } catch (e) {
              console.error(
                "Failed to fetch allocations for node",
                matchedNodeId,
                e
              );
            }

            if (chosenAllocationId === null) {
              cb();
              return res.redirect(`${redirectlink}?err=NOFREEALLOCATION`);
            }
          }

          // Optional premium-location gating: only enforced if the admin has
          // configured an entry in settings.json -> api.client.locations
          // matching either the selected node ID or the resolved location ID.
          const locationsCfg = newsettings.api.client.locations || {};
          const cfgEntry =
            locationsCfg[String(location)] ||
            locationsCfg[String(deployLocationId)] ||
            (matchedNodeId !== null ? locationsCfg[String(matchedNodeId)] : undefined);
          if (cfgEntry && cfgEntry.package) {
            const requiredpackage = cfgEntry.package;
            if (
              !requiredpackage.includes(
                packagename
                  ? packagename
                  : newsettings.api.client.packages.default
              )
            ) {
              cb();
              return res.redirect(`${redirectlink}?err=PREMIUMLOCATION`);
            }
          }

          let eggId = parseInt(req.query.egg);
          
          // Validate egg ID is a number
          if (isNaN(eggId)) {
            cb();
            return res.redirect(`${redirectlink}?err=INVALIDEGG`);
          }

          // Fetch all nests to find which nest contains this egg
          let nestsResponse = await fetch(
            `${newsettings.pterodactyl.domain}/api/application/nests`,
            {
              method: "get",
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${newsettings.pterodactyl.key}`,
              },
            }
          );

          if (!nestsResponse.ok) {
            cb();
            return res.redirect(`${redirectlink}?err=INVALIDEGG`);
          }

          let nestsData = await nestsResponse.json();
          let eggData = null;
          let nestId = null;

          // Find the egg in all nests
          for (const nest of nestsData.data) {
            let eggsResponse = await fetch(
              `${newsettings.pterodactyl.domain}/api/application/nests/${nest.attributes.id}/eggs/${eggId}?include=variables`,
              {
                method: "get",
                headers: {
                  "Content-Type": "application/json",
                  Authorization: `Bearer ${newsettings.pterodactyl.key}`,
                },
              }
            );

            if (eggsResponse.ok) {
              eggData = await eggsResponse.json();
              nestId = nest.attributes.id;
              break;
            }
          }

          if (!eggData) {
            cb();
            return res.redirect(`${redirectlink}?err=INVALIDEGG`);
          }

          let eggAttributes = eggData.attributes;

          let ram = parseFloat(req.query.ram);
          let disk = parseFloat(req.query.disk);
          let cpu = parseFloat(req.query.cpu);

          // Optional feature_limits inputs (default to 1 each if not provided)
          let backups = req.query.backups !== undefined ? parseInt(req.query.backups) : 1;
          let databases = req.query.databases !== undefined ? parseInt(req.query.databases) : 1;
          let allocations = req.query.allocations !== undefined ? parseInt(req.query.allocations) : 1;
          if (isNaN(backups) || backups < 0) backups = 0;
          if (isNaN(databases) || databases < 0) databases = 0;
          if (isNaN(allocations) || allocations < 1) allocations = 1; // Pterodactyl requires >= 1

          // Package defaults for new feature limits (fallback to 1 if absent)
          const pkgBackups = typeof package.backups === "number" ? package.backups : 1;
          const pkgDatabases = typeof package.databases === "number" ? package.databases : 1;
          const pkgAllocations = typeof package.allocations === "number" ? package.allocations : 1;
          
          if (!isNaN(ram) && !isNaN(disk) && !isNaN(cpu)) {
            if (ram2 + ram > package.ram + extra.ram) {
              cb();
              return res.redirect(
                `${redirectlink}?err=EXCEEDRAM&num=${
                  package.ram + extra.ram - ram2
                }`
              );
            }
            if (disk2 + disk > package.disk + extra.disk) {
              cb();
              return res.redirect(
                `${redirectlink}?err=EXCEEDDISK&num=${
                  package.disk + extra.disk - disk2
                }`
              );
            }
            if (cpu2 + cpu > package.cpu + extra.cpu) {
              cb();
              return res.redirect(
                `${redirectlink}?err=EXCEEDCPU&num=${
                  package.cpu + extra.cpu - cpu2
                }`
              );
            }
            if (backups2 + backups > pkgBackups + extra.backups) {
              cb();
              return res.redirect(
                `${redirectlink}?err=EXCEEDBACKUPS&num=${
                  pkgBackups + extra.backups - backups2
                }`
              );
            }
            if (databases2 + databases > pkgDatabases + extra.databases) {
              cb();
              return res.redirect(
                `${redirectlink}?err=EXCEEDDATABASES&num=${
                  pkgDatabases + extra.databases - databases2
                }`
              );
            }
            if (allocations2 + allocations > pkgAllocations + extra.allocations) {
              cb();
              return res.redirect(
                `${redirectlink}?err=EXCEEDALLOCATIONS&num=${
                  pkgAllocations + extra.allocations - allocations2
                }`
              );
            }

            // Build environment variables from egg
            let environment = {};
            if (eggData.attributes.relationships && eggData.attributes.relationships.variables) {
              eggData.attributes.relationships.variables.data.forEach(variable => {
                environment[variable.attributes.env_variable] = variable.attributes.default_value;
              });
            }

            // Build server creation spec
            let specs = {
              name: name,
              user: await db.get("users-" + req.session.userinfo.id),
              egg: eggId,
              docker_image: eggAttributes.docker_image,
              startup: eggAttributes.startup,
              environment: environment,
              limits: {
                memory: ram,
                swap: -1,
                disk: disk,
                io: 500,
                cpu: cpu,
              },
              feature_limits: {
                databases: databases,
                backups: backups,
                allocations: allocations,
              },
            };

            if (chosenAllocationId !== null) {
              // Force the exact node by passing a pre-resolved allocation.
              specs.allocation = {
                default: chosenAllocationId,
                additional: [],
              };
            } else {
              // Legacy fallback: caller picked a location ID, let the panel
              // place the server on any node in that location.
              specs.deploy = {
                locations: [deployLocationId],
                dedicated_ip: false,
                port_range: [],
              };
            }

            let serverinfo = await fetch(
              settings.pterodactyl.domain + "/api/application/servers",
              {
                method: "post",
                headers: {
                  "Content-Type": "application/json",
                  Authorization: `Bearer ${settings.pterodactyl.key}`,
                  Accept: "application/json",
                },
                body: JSON.stringify(await specs),
              }
            );
            await serverinfo;
            if (serverinfo.statusText !== "Created") {
              console.log(await serverinfo.text());
              cb();
              return res.redirect(`${redirectlink}?err=ERRORONCREATE`);
            }
            let serverinfotext = await serverinfo.json();
            let newpterodactylinfo = req.session.pterodactyl;
            newpterodactylinfo.relationships.servers.data.push(serverinfotext);
            req.session.pterodactyl = newpterodactylinfo;

            // Set initial server expiry date
            const newsettings2 = JSON.parse(fs.readFileSync("./settings.json").toString());
            if (newsettings2.api.client.serverDuration && newsettings2.api.client.serverDuration.enabled) {
              const defaultDays = newsettings2.api.client.serverDuration.defaultDays || 7;
              const expiryDate = Date.now() + (defaultDays * 24 * 60 * 60 * 1000);
              await db.set(`server-expiry-${serverinfotext.attributes.id}`, expiryDate);
            }

            cb();
            log(
              "created server",
              `${req.session.userinfo.username}#${req.session.userinfo.discriminator} created a new server named \`${name}\` with the following specs:\n\`\`\`Memory: ${ram} MB\nCPU: ${cpu}%\nDisk: ${disk}\`\`\``
            );
            return res.redirect("/servers?err=CREATED");
          } else {
            cb();
            res.redirect(`${redirectlink}?err=NOTANUMBER`);
          }
        } else {
          cb();
          res.redirect(`${redirectlink}?err=MISSINGVARIABLE`);
        }
      });
    } else {
      res.redirect(
        theme.settings.redirect.createserverdisabled
          ? theme.settings.redirect.createserverdisabled
          : "/"
      );
    }
  });

  app.get("/modify", async (req, res) => {
    if (!req.session.pterodactyl) return res.redirect("/login");

    let theme = indexjs.get(req);

    let newsettings = JSON.parse(fs.readFileSync("./settings.json").toString());
    if (newsettings.api.client.allow.server.modify == true) {
      if (!req.query.id) return res.send("Missing server id.");

      const cacheaccount = await getPteroUser(
        req.session.userinfo.id,
        db
      ).catch(() => {
        return res.send(
          "An error has occured while attempting to update your account information and server list."
        );
      });
      if (!cacheaccount) return;
      req.session.pterodactyl = cacheaccount.attributes;

      let redirectlink = theme.settings.redirect.failedmodifyserver
        ? theme.settings.redirect.failedmodifyserver
        : "/"; // fail redirect link

      let checkexist =
        req.session.pterodactyl.relationships.servers.data.filter(
          (name) => name.attributes.id == req.query.id
        );
      if (checkexist.length !== 1) return res.send("Invalid server id.");

      let ram = req.query.ram
        ? isNaN(parseFloat(req.query.ram))
          ? undefined
          : parseFloat(req.query.ram)
        : undefined;
      let disk = req.query.disk
        ? isNaN(parseFloat(req.query.disk))
          ? undefined
          : parseFloat(req.query.disk)
        : undefined;
      let cpu = req.query.cpu
        ? isNaN(parseFloat(req.query.cpu))
          ? undefined
          : parseFloat(req.query.cpu)
        : undefined;
      let backups = req.query.backups !== undefined && !isNaN(parseInt(req.query.backups))
        ? parseInt(req.query.backups)
        : undefined;
      let databases = req.query.databases !== undefined && !isNaN(parseInt(req.query.databases))
        ? parseInt(req.query.databases)
        : undefined;
      let allocations = req.query.allocations !== undefined && !isNaN(parseInt(req.query.allocations))
        ? parseInt(req.query.allocations)
        : undefined;

      if (ram || disk || cpu || backups !== undefined || databases !== undefined || allocations !== undefined) {
        let newsettings = JSON.parse(
          fs.readFileSync("./settings.json").toString()
        );

        let packagename = await db.get("package-" + req.session.userinfo.id);
        let package =
          newsettings.api.client.packages.list[
            packagename ? packagename : newsettings.api.client.packages.default
          ];

        let pterorelationshipsserverdata =
          req.session.pterodactyl.relationships.servers.data.filter(
            (name) => name.attributes.id.toString() !== req.query.id
          );

        let ram2 = 0;
        let disk2 = 0;
        let cpu2 = 0;
        let backups2 = 0;
        let databases2 = 0;
        let allocations2 = 0;
        for (
          let i = 0, len = pterorelationshipsserverdata.length;
          i < len;
          i++
        ) {
          const s = pterorelationshipsserverdata[i].attributes;
          ram2 = ram2 + (s.limits.memory || 0);
          disk2 = disk2 + (s.limits.disk || 0);
          cpu2 = cpu2 + (s.limits.cpu || 0);
          backups2 = backups2 + ((s.feature_limits && s.feature_limits.backups) || 0);
          databases2 = databases2 + ((s.feature_limits && s.feature_limits.databases) || 0);
          allocations2 = allocations2 + ((s.feature_limits && s.feature_limits.allocations) || 0);
        }
        
        // Get current server for defaults
        let currentServer = checkexist[0];

        let extra = (await db.get("extra-" + req.session.userinfo.id))
          ? await db.get("extra-" + req.session.userinfo.id)
          : {
              ram: 0,
              disk: 0,
              cpu: 0,
              servers: 0,
              backups: 0,
              databases: 0,
              allocations: 0,
            };
        if (typeof extra.backups !== "number") extra.backups = 0;
        if (typeof extra.databases !== "number") extra.databases = 0;
        if (typeof extra.allocations !== "number") extra.allocations = 0;

        const pkgBackups = typeof package.backups === "number" ? package.backups : 1;
        const pkgDatabases = typeof package.databases === "number" ? package.databases : 1;
        const pkgAllocations = typeof package.allocations === "number" ? package.allocations : 1;

        if (ram && ram2 + ram > package.ram + extra.ram)
          return res.redirect(
            `${redirectlink}?id=${req.query.id}&err=EXCEEDRAM&num=${
              package.ram + extra.ram - ram2
            }`
          );
        if (disk && disk2 + disk > package.disk + extra.disk)
          return res.redirect(
            `${redirectlink}?id=${req.query.id}&err=EXCEEDDISK&num=${
              package.disk + extra.disk - disk2
            }`
          );
        if (cpu && cpu2 + cpu > package.cpu + extra.cpu)
          return res.redirect(
            `${redirectlink}?id=${req.query.id}&err=EXCEEDCPU&num=${
              package.cpu + extra.cpu - cpu2
            }`
          );
        if (backups !== undefined && backups2 + backups > pkgBackups + extra.backups)
          return res.redirect(
            `${redirectlink}?id=${req.query.id}&err=EXCEEDBACKUPS&num=${
              pkgBackups + extra.backups - backups2
            }`
          );
        if (databases !== undefined && databases2 + databases > pkgDatabases + extra.databases)
          return res.redirect(
            `${redirectlink}?id=${req.query.id}&err=EXCEEDDATABASES&num=${
              pkgDatabases + extra.databases - databases2
            }`
          );
        if (allocations !== undefined && allocations2 + allocations > pkgAllocations + extra.allocations)
          return res.redirect(
            `${redirectlink}?id=${req.query.id}&err=EXCEEDALLOCATIONS&num=${
              pkgAllocations + extra.allocations - allocations2
            }`
          );

        let limits = {
          memory: ram ? ram : currentServer.attributes.limits.memory,
          disk: disk ? disk : currentServer.attributes.limits.disk,
          cpu: cpu ? cpu : currentServer.attributes.limits.cpu,
          swap: currentServer.attributes.limits.swap || 0,
          io: currentServer.attributes.limits.io || 500,
        };

        const currentFeatures = currentServer.attributes.feature_limits || {};
        let feature_limits = {
          databases: databases !== undefined ? databases : (currentFeatures.databases || 0),
          backups: backups !== undefined ? backups : (currentFeatures.backups || 0),
          allocations: allocations !== undefined ? allocations : (currentFeatures.allocations || 1),
        };
        // Pterodactyl requires allocations >= 1
        if (feature_limits.allocations < 1) feature_limits.allocations = 1;

        let serverinfo = await fetch(
          settings.pterodactyl.domain +
            "/api/application/servers/" +
            req.query.id +
            "/build",
          {
            method: "PATCH",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${settings.pterodactyl.key}`,
              Accept: "application/json",
            },
            body: JSON.stringify({
              limits: limits,
              feature_limits: feature_limits,
              allocation: currentServer.attributes.allocation,
            }),
          }
        );
        
        if (!serverinfo.ok) {
          const errorText = await serverinfo.text();
          console.error("Pterodactyl API Error:", errorText);
          console.error("Status:", serverinfo.status, serverinfo.statusText);
          return res.redirect(
            `${redirectlink}?id=${req.query.id}&err=ERRORONMODIFY`
          );
        }
        
        let text = await serverinfo.json();
        log(
          `modify server`,
          `${req.session.userinfo.username}#${req.session.userinfo.discriminator} modified the server called \`${text.attributes.name}\` to have the following specs:\n\`\`\`Memory: ${ram} MB\nCPU: ${cpu}%\nDisk: ${disk}\`\`\``
        );
        pterorelationshipsserverdata.push(text);
        req.session.pterodactyl.relationships.servers.data =
          pterorelationshipsserverdata;
        let theme = indexjs.get(req);
        adminjs.suspend(req.session.userinfo.id);
        res.redirect("/servers?err=MODIFIED");
      } else {
        res.redirect(`${redirectlink}?id=${req.query.id}&err=MISSINGVARIABLE`);
      }
    } else {
      res.redirect(
        theme.settings.redirect.modifyserverdisabled
          ? theme.settings.redirect.modifyserverdisabled
          : "/"
      );
    }
  });

  app.get("/delete", async (req, res) => {
    if (!req.session.pterodactyl) return res.redirect("/login");

    if (!req.query.id) return res.send("Missing id.");

    let theme = indexjs.get(req);

    let newsettings = JSON.parse(fs.readFileSync("./settings.json").toString());
    if (newsettings.api.client.allow.server.delete == true) {
      if (
        req.session.pterodactyl.relationships.servers.data.filter(
          (server) => server.attributes.id == req.query.id
        ).length == 0
      )
        return res.send("Could not find server with that ID.");

      let deletionresults = await fetch(
        settings.pterodactyl.domain +
          "/api/application/servers/" +
          req.query.id,
        {
          method: "delete",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${settings.pterodactyl.key}`,
          },
        }
      );
      let ok = await deletionresults.ok;
      if (ok !== true)
        return res.send(
          "An error has occur while attempting to delete the server."
        );
      let pterodactylinfo = req.session.pterodactyl;
      pterodactylinfo.relationships.servers.data =
        pterodactylinfo.relationships.servers.data.filter(
          (server) => server.attributes.id.toString() !== req.query.id
        );
      req.session.pterodactyl = pterodactylinfo;

      adminjs.suspend(req.session.userinfo.id);

      return res.redirect("/servers?err=DELETED");
    } else {
      res.redirect(
        theme.settings.redirect.deleteserverdisabled
          ? theme.settings.redirect.deleteserverdisabled
          : "/"
      );
    }
  });
};
