import { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { Play, Pause, RotateCcw, Flame, Coffee, Trophy } from 'lucide-react';

type TimerMode = 'pomodoro' | 'short' | 'long';

interface Preset {
  label: string;
  minutes: number;
  mode: TimerMode;
  icon: typeof Flame;
  colorClass: string;
}

const PRESETS: Preset[] = [
  { label: 'Focus', minutes: 25, mode: 'pomodoro', icon: Flame, colorClass: 'text-orange-500 bg-orange-500/10 border-orange-500/20' },
  { label: 'Short Break', minutes: 5, mode: 'short', icon: Coffee, colorClass: 'text-blue-400 bg-blue-400/10 border-blue-400/20' },
  { label: 'Long Break', minutes: 15, mode: 'long', icon: Trophy, colorClass: 'text-emerald-400 bg-emerald-400/10 border-emerald-400/20' },
];

export default function FocusTimer() {
  const [activeMode, setActiveMode] = useState<TimerMode>('pomodoro');
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [sessionsCompleted, setSessionsCompleted] = useState(0);

  const activePreset = PRESETS.find((p) => p.mode === activeMode) || PRESETS[0];
  const totalSeconds = activePreset.minutes * 60;
  const progress = timeLeft / totalSeconds;

  // Sound generator
  const playAlertSound = () => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      
      // Play a nice double-chime sound
      const playChime = (time: number, freq: number) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, time);
        
        gain.gain.setValueAtTime(0, time);
        gain.gain.linearRampToValueAtTime(0.3, time + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.001, time + 0.5);
        
        osc.start(time);
        osc.stop(time + 0.5);
      };

      const now = ctx.currentTime;
      playChime(now, 880); // A5
      playChime(now + 0.15, 1109.73); // C#6
      playChime(now + 0.3, 1318.51); // E6
    } catch (e) {
      console.error('AudioContext sound failed to load:', e);
    }
  };

  useEffect(() => {
    let intervalId: any = null;
    if (isRunning && timeLeft > 0) {
      intervalId = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setIsRunning(false);
      playAlertSound();
      if (activeMode === 'pomodoro') {
        setSessionsCompleted((prev) => prev + 1);
      }
    }
    return () => {
      if (intervalId) clearInterval(intervalId);
    };
  }, [isRunning, timeLeft, activeMode]);

  const handleModeChange = (mode: TimerMode, minutes: number) => {
    setIsRunning(false);
    setActiveMode(mode);
    setTimeLeft(minutes * 60);
  };

  const toggleTimer = () => {
    setIsRunning(!isRunning);
  };

  const resetTimer = () => {
    setIsRunning(false);
    setTimeLeft(activePreset.minutes * 60);
  };

  const formatTimeLeft = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const circumference = 2 * Math.PI * 45; // r=45
  const strokeDashoffset = circumference * (1 - progress);

  return (
    <div id="focus-timer" className="bg-neutral-900/60 backdrop-blur-md border border-neutral-800 rounded-2xl p-6 shadow-xl relative overflow-hidden flex flex-col justify-between h-full">
      <div className="absolute top-0 right-0 w-32 h-32 bg-orange-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2 text-neutral-400 text-xs font-mono tracking-wider uppercase">
            <Flame className="w-4 h-4 text-orange-500" />
            <span>Focus Engine</span>
          </div>
          <div className="flex items-center gap-1 bg-neutral-800/50 px-2 py-0.5 rounded-full text-[11px] font-mono text-neutral-400 border border-neutral-800/50">
            <span>Sessions:</span>
            <span className="text-orange-400 font-semibold">{sessionsCompleted}</span>
          </div>
        </div>

        {/* Mode Selector */}
        <div className="grid grid-cols-3 gap-1.5 p-1 bg-neutral-950/80 rounded-xl border border-neutral-800/40">
          {PRESETS.map((preset) => {
            const Icon = preset.icon;
            const isActive = activeMode === preset.mode;
            return (
              <button
                key={preset.mode}
                onClick={() => handleModeChange(preset.mode, preset.minutes)}
                className={`flex flex-col sm:flex-row items-center justify-center gap-1.5 py-1.5 px-2 rounded-lg text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-neutral-800 text-white shadow-inner border border-neutral-700/50'
                    : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900/30'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? preset.colorClass.split(' ')[0] : 'text-neutral-500'}`} />
                <span className="truncate">{preset.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Timer Visualizer & Display */}
      <div className="flex flex-col items-center justify-center py-6 relative">
        <div className="relative w-40 h-40 flex items-center justify-center">
          <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
            {/* Background Circle */}
            <circle
              cx="50"
              cy="50"
              r="45"
              className="stroke-neutral-850 fill-transparent"
              strokeWidth="4"
            />
            {/* Animated Ring */}
            <motion.circle
              cx="50"
              cy="50"
              r="45"
              className={`fill-transparent ${
                activeMode === 'pomodoro'
                  ? 'stroke-orange-500'
                  : activeMode === 'short'
                  ? 'stroke-blue-400'
                  : 'stroke-emerald-400'
              }`}
              strokeWidth="4"
              strokeDasharray={circumference}
              animate={{ strokeDashoffset }}
              transition={{ duration: 0.3, ease: 'linear' }}
              strokeLinecap="round"
            />
          </svg>

          {/* Time digits */}
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="font-display font-bold text-3xl md:text-4xl text-white tracking-tight tabular-nums">
              {formatTimeLeft(timeLeft)}
            </span>
            <span className="text-[10px] text-neutral-500 font-mono tracking-widest uppercase mt-0.5">
              {isRunning ? 'active' : 'paused'}
            </span>
          </div>
        </div>
      </div>

      {/* Action Controls */}
      <div className="flex items-center justify-center gap-3">
        <button
          onClick={resetTimer}
          className="p-2.5 rounded-xl bg-neutral-950 hover:bg-neutral-900 border border-neutral-800 hover:border-neutral-700 text-neutral-400 hover:text-neutral-100 transition-all cursor-pointer"
          title="Reset timer"
        >
          <RotateCcw className="w-4 h-4" />
        </button>

        <button
          onClick={toggleTimer}
          className={`flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-medium transition-all shadow-md hover:shadow-lg cursor-pointer ${
            isRunning
              ? 'bg-neutral-800 text-neutral-200 border border-neutral-700 hover:bg-neutral-700/80'
              : activeMode === 'pomodoro'
              ? 'bg-orange-500 text-neutral-950 font-semibold hover:bg-orange-400'
              : activeMode === 'short'
              ? 'bg-blue-400 text-neutral-950 font-semibold hover:bg-blue-300'
              : 'bg-emerald-400 text-neutral-950 font-semibold hover:bg-emerald-300'
          }`}
        >
          {isRunning ? (
            <>
              <Pause className="w-4 h-4 fill-current" />
              <span>Pause</span>
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-current" />
              <span>Start Focus</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
}
