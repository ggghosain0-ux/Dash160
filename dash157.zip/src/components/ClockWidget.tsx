import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Globe, Clock, Compass } from 'lucide-react';

interface TimezoneOption {
  label: string;
  value: string;
}

const TIMEZONES: TimezoneOption[] = [
  { label: 'Local Time', value: 'local' },
  { label: 'UTC', value: 'UTC' },
  { label: 'New York (EST)', value: 'America/New_York' },
  { label: 'London (GMT)', value: 'Europe/London' },
  { label: 'Tokyo (JST)', value: 'Asia/Tokyo' },
  { label: 'Sydney (AEST)', value: 'Australia/Sydney' },
];

export default function ClockWidget() {
  const [time, setTime] = useState(new Date());
  const [selectedZone, setSelectedZone] = useState('local');

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (date: Date, zone: string) => {
    if (zone === 'local') {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
    }
    return date.toLocaleTimeString([], {
      timeZone: zone,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false,
    });
  };

  const formatDate = (date: Date, zone: string) => {
    const options: Intl.DateTimeFormatOptions = {
      weekday: 'long',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    };
    if (zone === 'local') {
      return date.toLocaleDateString([], options);
    }
    return date.toLocaleDateString([], { ...options, timeZone: zone });
  };

  const unixTimestamp = Math.floor(time.getTime() / 1000);

  return (
    <div id="clock-widget" className="bg-neutral-900/60 backdrop-blur-md border border-neutral-800 rounded-2xl p-6 shadow-xl relative overflow-hidden flex flex-col justify-between h-full">
      {/* Background ambient radial glow */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />

      <div>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2 text-neutral-400 text-xs font-mono tracking-wider uppercase">
            <Clock id="clock-icon" className="w-4 h-4 text-neutral-500" />
            <span>Timepiece</span>
          </div>
          <div className="flex items-center gap-1.5 bg-neutral-800/80 px-2 py-1 rounded-md text-xs font-mono text-neutral-400">
            <Globe className="w-3.5 h-3.5 text-neutral-500" />
            <select
              value={selectedZone}
              onChange={(e) => setSelectedZone(e.target.value)}
              className="bg-transparent border-none outline-none cursor-pointer text-xs font-medium text-neutral-300 hover:text-neutral-100 transition-colors"
            >
              {TIMEZONES.map((tz) => (
                <option key={tz.value} value={tz.value} className="bg-neutral-950 text-neutral-300">
                  {tz.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="mt-2">
          <motion.div
            key={selectedZone}
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="font-display font-semibold text-5xl md:text-6xl text-white tracking-tight leading-none tabular-nums flex items-center gap-2"
          >
            {formatTime(time, selectedZone)}
            <motion.span
              animate={{ opacity: [1, 0.4, 1] }}
              transition={{ repeat: Infinity, duration: 2 }}
              className="w-1.5 h-1.5 rounded-full bg-emerald-500 self-end mb-2.5 ml-1"
            />
          </motion.div>

          <p className="text-neutral-400 text-sm mt-2 font-sans tracking-wide">
            {formatDate(time, selectedZone)}
          </p>
        </div>
      </div>

      <div className="mt-6 pt-4 border-t border-neutral-800/60 flex items-center justify-between text-[11px] text-neutral-500 font-mono">
        <div className="flex items-center gap-1.5">
          <Compass className="w-3.5 h-3.5" />
          <span>EPOCH SECONDS</span>
        </div>
        <span className="text-neutral-400 tabular-nums font-medium">{unixTimestamp}</span>
      </div>
    </div>
  );
}
