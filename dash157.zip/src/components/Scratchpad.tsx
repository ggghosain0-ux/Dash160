import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { FileText, Plus, Trash2, Copy, Check, Save } from 'lucide-react';
import { Note } from '../types';

export default function Scratchpad() {
  const [notes, setNotes] = useState<Note[]>(() => {
    const saved = localStorage.getItem('dash157_notes');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return [
      {
        id: '1',
        title: 'Project Ideas',
        content: 'Welcome to dash157!\n- Build high-craft, single-screen dashboard\n- Keep design elegant with cosmic-slate theme\n- Enjoy local storage state management',
        updatedAt: new Date().toLocaleDateString(),
      },
    ];
  });

  const [activeNoteId, setActiveNoteId] = useState<string>(notes[0]?.id || '');
  const [copied, setCopied] = useState(false);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('dash157_notes', JSON.stringify(notes));
  }, [notes]);

  const activeNote = notes.find((note) => note.id === activeNoteId) || notes[0];

  const handleCreateNote = () => {
    const newNote: Note = {
      id: Date.now().toString(),
      title: 'Untitled Note',
      content: '',
      updatedAt: new Date().toLocaleDateString(),
    };
    setNotes([newNote, ...notes]);
    setActiveNoteId(newNote.id);
  };

  const handleUpdateContent = (content: string) => {
    setNotes(
      notes.map((note) => {
        if (note.id === activeNoteId) {
          // Extra step: auto-generate title from first line if still "Untitled Note"
          let title = note.title;
          if (note.title === 'Untitled Note' || !note.title.trim()) {
            const firstLine = content.trim().split('\n')[0];
            if (firstLine && firstLine.length < 24) {
              title = firstLine;
            }
          }
          return {
            ...note,
            content,
            title,
            updatedAt: new Date().toLocaleDateString(),
          };
        }
        return note;
      })
    );
  };

  const handleUpdateTitle = (title: string) => {
    setNotes(
      notes.map((note) =>
        note.id === activeNoteId
          ? { ...note, title, updatedAt: new Date().toLocaleDateString() }
          : note
      )
    );
  };

  const handleDeleteNote = (id: string) => {
    if (notes.length <= 1) {
      // Don't let users delete the last note, just clear it
      setNotes([
        {
          id: Date.now().toString(),
          title: 'Scratchpad',
          content: '',
          updatedAt: new Date().toLocaleDateString(),
        },
      ]);
      return;
    }
    const filtered = notes.filter((note) => note.id !== id);
    setNotes(filtered);
    if (activeNoteId === id) {
      setActiveNoteId(filtered[0].id);
    }
  };

  const handleCopy = () => {
    if (!activeNote) return;
    navigator.clipboard.writeText(activeNote.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const wordCount = activeNote?.content ? activeNote.content.trim().split(/\s+/).filter(Boolean).length : 0;
  const charCount = activeNote?.content ? activeNote.content.length : 0;

  return (
    <div id="scratchpad-widget" className="bg-neutral-900/60 backdrop-blur-md border border-neutral-800 rounded-2xl p-6 shadow-xl relative overflow-hidden flex flex-col h-full">
      <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2 text-neutral-400 text-xs font-mono tracking-wider uppercase">
          <FileText className="w-4 h-4 text-purple-400" />
          <span>Quick Scratchpad</span>
        </div>
        <button
          onClick={handleCreateNote}
          className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/20 hover:border-purple-500/30 text-purple-300 text-xs font-medium transition-all cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Memo</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 flex-1 min-h-[250px]">
        {/* Notes Sidebar */}
        <div className="md:col-span-1 flex flex-col gap-1.5 overflow-y-auto max-h-[160px] md:max-h-[300px] pr-1 border-b md:border-b-0 md:border-r border-neutral-800 pb-3 md:pb-0">
          <span className="text-[10px] text-neutral-500 font-mono uppercase tracking-wider mb-1 block">Your Saved Memos</span>
          <div className="flex flex-row md:flex-col gap-1.5 overflow-x-auto md:overflow-x-visible pb-2 md:pb-0">
            {notes.map((note) => (
              <button
                key={note.id}
                onClick={() => setActiveNoteId(note.id)}
                className={`flex-shrink-0 flex items-center justify-between gap-2 text-left px-3 py-2 rounded-lg text-xs transition-all w-44 md:w-full ${
                  activeNoteId === note.id
                    ? 'bg-neutral-800 text-white border border-neutral-700/50 shadow-inner'
                    : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900/30 border border-transparent'
                }`}
              >
                <div className="truncate flex-1">
                  <p className="font-medium truncate">{note.title || 'Untitled Note'}</p>
                  <p className="text-[10px] text-neutral-500 mt-0.5">{note.updatedAt}</p>
                </div>
                {notes.length > 1 && activeNoteId === note.id && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDeleteNote(note.id);
                    }}
                    className="p-1 rounded text-neutral-500 hover:text-red-400 hover:bg-neutral-700/30 transition-all"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Note Editor Workspace */}
        <div className="md:col-span-2 flex flex-col justify-between h-full">
          {activeNote ? (
            <div className="flex flex-col flex-1 h-full">
              <input
                type="text"
                value={activeNote.title}
                onChange={(e) => handleUpdateTitle(e.target.value)}
                className="bg-transparent border-none text-neutral-100 font-display font-medium text-sm focus:outline-none focus:ring-0 w-full mb-2 placeholder-neutral-600"
                placeholder="Title..."
              />
              <textarea
                value={activeNote.content}
                onChange={(e) => handleUpdateContent(e.target.value)}
                placeholder="Start scribbling your thoughts here..."
                className="flex-1 w-full min-h-[140px] md:min-h-[180px] bg-transparent border-none text-neutral-300 font-sans text-xs focus:outline-none focus:ring-0 resize-none placeholder-neutral-600 leading-relaxed pr-1"
              />
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center text-neutral-600 text-xs">
              No active note. Create a new memo.
            </div>
          )}

          {/* Footer of workspace */}
          <div className="border-t border-neutral-850 pt-3 mt-2 flex items-center justify-between text-[11px] text-neutral-500 font-mono">
            <div className="flex items-center gap-3">
              <span>{wordCount} Words</span>
              <span>{charCount} Chars</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handleCopy}
                disabled={!activeNote}
                className="flex items-center gap-1 hover:text-neutral-200 transition-colors cursor-pointer"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy</span>
                  </>
                )}
              </button>
              <span className="text-neutral-700">|</span>
              <div className="flex items-center gap-1 text-emerald-500/80">
                <Save className="w-3 h-3" />
                <span>Auto-saved</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
