import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Droplet, Heart, Plus, Minus, Zap, Sparkles } from 'lucide-react';
import { MetricTracker } from '../types';

export default function QuickMetrics() {
  const [trackers, setTrackers] = useState<MetricTracker[]>(() => {
    const saved = localStorage.getItem('dash157_trackers');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return [
      { id: 'water', name: 'Hydration Target', value: 750, target: 2000, unit: 'ml', color: 'text-blue-400 bg-blue-500/10 border-blue-500/10 bar-color' },
      { id: 'coffee', name: 'Caffeine Intake', value: 2, target: 4, unit: 'cups', color: 'text-amber-500 bg-amber-500/10 border-amber-500/10' },
      { id: 'pushups', name: 'Active Calisthenics', value: 20, target: 50, unit: 'reps', color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/10' },
    ];
  });

  const [mood, setMood] = useState<number>(() => {
    const saved = localStorage.getItem('dash157_mood');
    return saved ? parseInt(saved, 10) : 4;
  });

  useEffect(() => {
    localStorage.setItem('dash157_trackers', JSON.stringify(trackers));
  }, [trackers]);

  useEffect(() => {
    localStorage.setItem('dash157_mood', mood.toString());
  }, [mood]);

  const handleIncrement = (id: string, amount: number) => {
    setTrackers(
      trackers.map((t) => {
        if (t.id === id) {
          const newVal = Math.max(0, t.value + amount);
          return { ...t, value: newVal };
        }
        return t;
      })
    );
  };

  const MOODS = [
    { label: '😞', text: 'Melancholy', score: 1 },
    { label: '😐', text: 'Stagnant', score: 2 },
    { label: '🙂', text: 'Steady', score: 3 },
    { label: '✨', text: 'Aligned', score: 4 },
    { label: '🔥', text: 'Limitless', score: 5 },
  ];

  return (
    <div id="metrics-widget" className="bg-neutral-900/60 backdrop-blur-md border border-neutral-800 rounded-2xl p-6 shadow-xl relative overflow-hidden flex flex-col justify-between h-full">
      <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2 text-neutral-400 text-xs font-mono tracking-wider uppercase">
            <Zap className="w-4 h-4 text-emerald-400" />
            <span>Habits & Vibe</span>
          </div>
          <div className="flex items-center gap-1.5 text-[10px] font-mono text-neutral-500 uppercase">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Interactive Logs</span>
          </div>
        </div>

        {/* Dynamic Trackers */}
        <div className="space-y-4">
          {trackers.map((tracker) => {
            const completion = Math.min(100, Math.round((tracker.value / tracker.target) * 100));
            const isWater = tracker.id === 'water';
            const isCoffee = tracker.id === 'coffee';

            return (
              <div key={tracker.id} className="bg-neutral-950/40 border border-neutral-850 p-3 rounded-xl">
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    {isWater ? (
                      <Droplet className="w-4 h-4 text-blue-400" />
                    ) : isCoffee ? (
                      <Heart className="w-4 h-4 text-amber-500" />
                    ) : (
                      <Zap className="w-4 h-4 text-emerald-400" />
                    )}
                    <span className="text-xs font-medium text-neutral-300">{tracker.name}</span>
                  </div>
                  <span className="text-[11px] font-mono text-neutral-400 tabular-nums">
                    {tracker.value} / {tracker.target} <span className="text-neutral-500 text-[10px]">{tracker.unit}</span>
                  </span>
                </div>

                {/* Progress bar container */}
                <div className="flex items-center gap-3">
                  <div className="flex-1 bg-neutral-950 rounded-full h-1.5 overflow-hidden border border-neutral-850">
                    <motion.div
                      className={`h-full rounded-full ${
                        isWater ? 'bg-blue-400' : isCoffee ? 'bg-amber-500' : 'bg-emerald-400'
                      }`}
                      initial={{ width: 0 }}
                      animate={{ width: `${completion}%` }}
                      transition={{ duration: 0.4, ease: 'easeOut' }}
                    />
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleIncrement(tracker.id, isWater ? -250 : -1)}
                      className="p-1 rounded bg-neutral-900 border border-neutral-800 hover:border-neutral-700 hover:bg-neutral-850 text-neutral-400 hover:text-neutral-200 transition-all cursor-pointer"
                    >
                      <Minus className="w-2.5 h-2.5" />
                    </button>
                    <button
                      onClick={() => handleIncrement(tracker.id, isWater ? 250 : 1)}
                      className="p-1 rounded bg-neutral-900 border border-neutral-800 hover:border-neutral-700 hover:bg-neutral-850 text-neutral-400 hover:text-neutral-200 transition-all cursor-pointer"
                    >
                      <Plus className="w-2.5 h-2.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Mood Log Section */}
      <div className="border-t border-neutral-850 pt-4 mt-4">
        <span className="text-[10px] text-neutral-500 font-mono uppercase tracking-wider block mb-2">Vibe Alignment</span>
        <div className="grid grid-cols-5 gap-1.5 bg-neutral-950/50 p-1.5 rounded-xl border border-neutral-850">
          {MOODS.map((m) => {
            const isSelected = mood === m.score;
            return (
              <button
                key={m.score}
                onClick={() => setMood(m.score)}
                title={m.text}
                className={`py-2 rounded-lg text-lg flex flex-col items-center justify-center transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-neutral-800 border border-neutral-700/60 shadow-md scale-105'
                    : 'opacity-40 hover:opacity-80 hover:bg-neutral-900/40'
                }`}
              >
                <span>{m.label}</span>
                <span className="text-[8px] font-mono text-neutral-500 mt-0.5 truncate max-w-full scale-90">
                  {m.text}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
