import { useState, useEffect, FormEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckSquare, Square, Trash2, Plus, ListTodo, AlertCircle } from 'lucide-react';
import { Task } from '../types';

export default function TaskList() {
  const [tasks, setTasks] = useState<Task[]>(() => {
    const saved = localStorage.getItem('dash157_tasks');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return [
      { id: '1', text: 'Structure elegant single-screen viewport', completed: true, priority: 'high', createdAt: new Date().toISOString() },
      { id: '2', text: 'Configure custom Google Fonts in index.css', completed: true, priority: 'medium', createdAt: new Date().toISOString() },
      { id: '3', text: 'Implement AudioContext alerts in focus timer', completed: false, priority: 'high', createdAt: new Date().toISOString() },
      { id: '4', text: 'Double-check typescript verification of package config', completed: false, priority: 'low', createdAt: new Date().toISOString() },
    ];
  });

  const [newTaskText, setNewTaskText] = useState('');
  const [priority, setPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [filter, setFilter] = useState<'all' | 'active' | 'completed'>('all');

  useEffect(() => {
    localStorage.setItem('dash157_tasks', JSON.stringify(tasks));
  }, [tasks]);

  const handleAddTask = (e: FormEvent) => {
    e.preventDefault();
    if (!newTaskText.trim()) return;

    const newTask: Task = {
      id: Date.now().toString(),
      text: newTaskText.trim(),
      completed: false,
      priority,
      createdAt: new Date().toISOString(),
    };

    setTasks([newTask, ...tasks]);
    setNewTaskText('');
  };

  const handleToggleTask = (id: string) => {
    setTasks(
      tasks.map((task) =>
        task.id === id ? { ...task, completed: !task.completed } : task
      )
    );
  };

  const handleDeleteTask = (id: string) => {
    setTasks(tasks.filter((task) => task.id !== id));
  };

  const filteredTasks = tasks.filter((task) => {
    if (filter === 'active') return !task.completed;
    if (filter === 'completed') return task.completed;
    return true;
  });

  // Sort: incomplete first, then priority (high > medium > low)
  const priorityWeight = { high: 3, medium: 2, low: 1 };
  const sortedTasks = [...filteredTasks].sort((a, b) => {
    if (a.completed !== b.completed) {
      return a.completed ? 1 : -1;
    }
    return priorityWeight[b.priority] - priorityWeight[a.priority];
  });

  const completedCount = tasks.filter((t) => t.completed).length;
  const totalCount = tasks.length;
  const completionRate = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  return (
    <div id="tasklist-widget" className="bg-neutral-900/60 backdrop-blur-md border border-neutral-800 rounded-2xl p-6 shadow-xl relative overflow-hidden flex flex-col h-full">
      <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2 text-neutral-400 text-xs font-mono tracking-wider uppercase">
            <ListTodo className="w-4 h-4 text-emerald-400" />
            <span>Task Matrix</span>
          </div>
          <div className="flex items-center gap-2 text-[11px] font-mono text-neutral-400">
            <span>Progress:</span>
            <span className="text-emerald-400 font-bold">{completionRate}%</span>
          </div>
        </div>

        {/* Mini progress bar */}
        <div className="w-full bg-neutral-950 rounded-full h-1 mb-5 overflow-hidden border border-neutral-800/20">
          <motion.div
            className="bg-emerald-400 h-full rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${completionRate}%` }}
            transition={{ duration: 0.5, ease: 'easeOut' }}
          />
        </div>

        {/* Input Form */}
        <form onSubmit={handleAddTask} className="flex flex-col gap-2 mb-4">
          <div className="flex gap-2">
            <input
              type="text"
              value={newTaskText}
              onChange={(e) => setNewTaskText(e.target.value)}
              placeholder="Deploy dash157 applet..."
              className="flex-1 bg-neutral-950/80 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-neutral-200 placeholder-neutral-600 focus:outline-none focus:ring-1 focus:ring-emerald-500/30 focus:border-emerald-500/40"
            />
            <button
              type="submit"
              className="bg-emerald-400 hover:bg-emerald-300 text-neutral-950 px-3.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center cursor-pointer"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex gap-1">
              {(['low', 'medium', 'high'] as const).map((p) => (
                <button
                  type="button"
                  key={p}
                  onClick={() => setPriority(p)}
                  className={`text-[10px] font-mono px-2 py-0.5 rounded-md border capitalize transition-all ${
                    priority === p
                      ? p === 'high'
                        ? 'bg-red-500/10 border-red-500/30 text-red-400 font-semibold'
                        : p === 'medium'
                        ? 'bg-orange-500/10 border-orange-500/30 text-orange-400 font-semibold'
                        : 'bg-blue-500/10 border-blue-500/30 text-blue-400 font-semibold'
                      : 'bg-neutral-950/30 border-transparent text-neutral-500 hover:text-neutral-300'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>

            {/* Filter Toggle */}
            <div className="flex gap-1.5 text-[10px] font-mono bg-neutral-950/60 p-0.5 rounded-lg border border-neutral-800/40">
              {(['all', 'active', 'completed'] as const).map((f) => (
                <button
                  type="button"
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`px-1.5 py-0.5 rounded capitalize ${
                    filter === f ? 'bg-neutral-800 text-neutral-200 font-medium' : 'text-neutral-500 hover:text-neutral-300'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>
        </form>
      </div>

      {/* Task List container */}
      <div className="flex-1 overflow-y-auto max-h-[180px] md:max-h-[250px] pr-1 space-y-2">
        <AnimatePresence initial={false}>
          {sortedTasks.length > 0 ? (
            sortedTasks.map((task) => (
              <motion.div
                key={task.id}
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.2 }}
                className={`group flex items-start justify-between gap-3 p-2.5 rounded-xl border transition-all ${
                  task.completed
                    ? 'bg-neutral-950/20 border-neutral-900 text-neutral-500'
                    : 'bg-neutral-950/40 border-neutral-800/80 text-neutral-200 hover:border-neutral-700/60'
                }`}
              >
                <button
                  onClick={() => handleToggleTask(task.id)}
                  className="mt-0.5 flex-shrink-0 cursor-pointer"
                >
                  {task.completed ? (
                    <CheckSquare className="w-4 h-4 text-emerald-400 fill-emerald-950/20" />
                  ) : (
                    <Square className="w-4 h-4 text-neutral-600 hover:text-neutral-400 transition-colors" />
                  )}
                </button>

                <span className={`text-xs flex-1 break-words leading-normal select-none ${task.completed ? 'line-through decoration-neutral-700 text-neutral-600' : ''}`}>
                  {task.text}
                </span>

                <div className="flex items-center gap-1.5 flex-shrink-0">
                  {/* Priority Tag (hidden if completed for neatness, or dimmed) */}
                  {!task.completed && (
                    <span
                      className={`text-[9px] font-mono font-medium px-1.5 py-0.2 rounded uppercase ${
                        task.priority === 'high'
                          ? 'bg-red-500/10 text-red-400/80 border border-red-500/10'
                          : task.priority === 'medium'
                          ? 'bg-orange-500/10 text-orange-400/80 border border-orange-500/10'
                          : 'bg-blue-500/10 text-blue-400/80 border border-blue-500/10'
                      }`}
                    >
                      {task.priority[0]}
                    </span>
                  )}
                  <button
                    onClick={() => handleDeleteTask(task.id)}
                    className="opacity-0 group-hover:opacity-100 p-1 rounded hover:bg-neutral-800 text-neutral-500 hover:text-red-400 transition-all cursor-pointer"
                    title="Delete task"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </motion.div>
            ))
          ) : (
            <div className="h-20 flex flex-col items-center justify-center text-neutral-600 text-xs">
              <AlertCircle className="w-4 h-4 mb-1 text-neutral-700" />
              <span>No items found</span>
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
