import { useState } from 'react';
import { motion } from 'motion/react';
import { Terminal, Cpu, Layout, Info, Compass, HelpCircle } from 'lucide-react';
import ClockWidget from './components/ClockWidget';
import FocusTimer from './components/FocusTimer';
import Scratchpad from './components/Scratchpad';
import TaskList from './components/TaskList';
import QuickMetrics from './components/QuickMetrics';

export default function App() {
  const [showAbout, setShowAbout] = useState(false);

  // Stagger variants for entry
  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.08,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 15 },
    show: { opacity: 1, y: 0, transition: { type: 'spring', stiffness: 100, damping: 15 } },
  };

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-neutral-200 font-sans antialiased selection:bg-purple-500/30 selection:text-white pb-12">
      {/* Background visual atmosphere */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-emerald-500/3 rounded-full blur-3xl pointer-events-none" />

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        
        {/* Sleek Top Navigation/Bar */}
        <header className="flex items-center justify-between mb-8 pb-4 border-b border-neutral-900">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-neutral-900 border border-neutral-800 rounded-xl flex items-center justify-center">
              <span className="font-display font-bold text-lg text-white">d</span>
            </div>
            <div>
              <h1 className="font-display font-semibold text-xl text-white tracking-tight flex items-center gap-2">
                dash157 <span className="text-[10px] font-mono bg-purple-500/10 text-purple-400 border border-purple-500/20 px-1.5 py-0.5 rounded uppercase tracking-wider">v1.5.7</span>
              </h1>
              <p className="text-[10px] font-mono text-neutral-500 uppercase tracking-widest mt-0.5">Control center & workspace</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {/* System Status Indicators (Adhering to Human Labels & keeping clean) */}
            <div className="hidden sm:flex items-center gap-4 text-xs font-mono text-neutral-500 border-r border-neutral-900 pr-4">
              <div className="flex items-center gap-1.5">
                <Cpu className="w-3.5 h-3.5 text-neutral-600" />
                <span>WORKSPACE ID: <span className="text-neutral-400 font-medium">157</span></span>
              </div>
            </div>

            <button
              onClick={() => setShowAbout(!showAbout)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-900 hover:bg-neutral-850 border border-neutral-800 hover:border-neutral-700 text-neutral-400 hover:text-neutral-200 text-xs font-medium transition-all cursor-pointer"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>About Workspace</span>
            </button>
          </div>
        </header>

        {/* Informative Overlay Panel */}
        {showAbout && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="mb-8 p-5 rounded-2xl bg-neutral-900/40 border border-neutral-800 backdrop-blur-md relative"
          >
            <div className="absolute top-4 right-4">
              <button
                onClick={() => setShowAbout(false)}
                className="text-xs font-mono text-neutral-500 hover:text-neutral-300 transition-colors"
              >
                [Dismiss]
              </button>
            </div>
            <h2 className="text-sm font-display font-semibold text-white mb-2 flex items-center gap-2">
              <Info className="w-4 h-4 text-purple-400" />
              About dash157 Architecture
            </h2>
            <p className="text-xs text-neutral-400 leading-relaxed max-w-3xl">
              Welcome to your personal dashboard workspace. **dash157** is designed as a single-view personal terminal. It completely operates client-side with full state synchronization with your browser’s local storage. Feel free to use the focus timer, note down memos in the scratchpad, manage tasks, and log daily habit checkpoints.
            </p>
          </motion.div>
        )}

        {/* Dashboard Grid Modules */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="show"
          className="grid grid-cols-1 lg:grid-cols-3 gap-6"
        >
          {/* Module 1: Timepiece */}
          <motion.div variants={itemVariants} className="lg:col-span-1 min-h-[180px]">
            <ClockWidget />
          </motion.div>

          {/* Module 2: Focus Engine */}
          <motion.div variants={itemVariants} className="lg:col-span-1 min-h-[300px]">
            <FocusTimer />
          </motion.div>

          {/* Module 3: Metrics Tracker */}
          <motion.div variants={itemVariants} className="lg:col-span-1 min-h-[300px]">
            <QuickMetrics />
          </motion.div>

          {/* Module 4: Scratchpad (Spans 2 columns) */}
          <motion.div variants={itemVariants} className="lg:col-span-2 min-h-[350px]">
            <Scratchpad />
          </motion.div>

          {/* Module 5: Task Matrix */}
          <motion.div variants={itemVariants} className="lg:col-span-1 min-h-[350px]">
            <TaskList />
          </motion.div>
        </motion.div>

        {/* Footer */}
        <footer className="mt-12 pt-6 border-t border-neutral-950 flex flex-col sm:flex-row items-center justify-between text-xs text-neutral-600 font-mono">
          <div className="flex items-center gap-1.5">
            <Layout className="w-3.5 h-3.5" />
            <span>dash157 • Modern Minimal Workspace</span>
          </div>
          <div className="mt-2 sm:mt-0 flex items-center gap-1.5">
            <Compass className="w-3.5 h-3.5" />
            <span>All logs stored locally</span>
          </div>
        </footer>

      </div>
    </div>
  );
}
