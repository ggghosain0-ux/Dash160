export interface Note {
  id: string;
  title: string;
  content: string;
  updatedAt: string;
}

export interface Task {
  id: string;
  text: string;
  completed: boolean;
  priority: 'low' | 'medium' | 'high';
  createdAt: string;
}

export interface MetricTracker {
  id: string;
  name: string;
  value: number;
  target: number;
  unit: string;
  color: string;
}
